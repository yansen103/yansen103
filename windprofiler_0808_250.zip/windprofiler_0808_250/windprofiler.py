#! /usr/bin/env python
#coding=utf-8
import datetime
import glob
import os
import time

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import NullFormatter
from pylab import *

#from metpy.calc import *
#from netCDF4  import Dataset


class windprofiler:
    def read_profiler_hd(self,file):
        '''
        读取海淀风廓线资料
        '''
        #file = r'Y:\vertical\profiler\HD_54399\wind\Z_RADR_I_54399_20100415063600_P_WPRD_LC_ROBS.TXT'
        try:
            f = open(file,'r')
            lines = f.readlines()
            f.close()
            #print lines
            #读取实际资料是从第4行开始到最后第二行
            lens = range(len(lines))#有效资料长度
            wdd = []
            wff = []
            ww = []
            cn2 = []
            height = []

            stime = (lines[1].split(' '))[-1]
            year = stime[0:4]
            month = stime[4:6]
            day = stime[6:8]
            hour = stime[8:10]
            minute = stime[10:12]
            #print 'year=',year,'month=',month,'day=',day,'hour=',hour,'minute=',minute

            tt1 = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
            tt2  = tt1 + datetime.timedelta(hours = 8)#世界时转化为北京时
            #sst = tt2.timetuple()
            timeinfo = str(tt2)
            for i in lens[3:-1]:
                #print i,lines[i]
                data = lines[i].split(' ')
                print('data[1]:>>>>>>>',data[1])

                try:
                    height.append(float(data[0]))
                    print('height>>>>>>>>>>>>>>>>>>',height)
                except:
                    height.append(99999.9)
                try:
                    if float(data[1]) < 0.0 or float(data[1]) >360.0:

                        wdd.append(99999.9)
                        print('wdd>>>>',wdd)
                    else:
                        wdd.append(float(data[1]))
                except:
                    wdd.append(99999.9)
                try:
                    if float(data[2]) < 0.0 or float(data[2]) > 100.0:
                        wff.append(99999.9)
                    else:
                        wff.append(float(data[2]))
                except:
                    wff.append(99999.9)
                try:
                    ww.append(float(data[3]))
                except:
                    ww.append(99999.9)
                try:
                    cn2.append(float(data[6]))
                except:
                    cn2.append(99999.9)

            if len(height) != 34:
                height = [120., 180., 240., 300.0, 360., 420., \
                                          480., 540., 600.0, 660., 780., 900., \
                                          1020., 1140., 1260., 1380., 1500., 1620, \
                                          1740., 1860., 1980., 2100., 220., 2340., \
                                          2460., 2580., 2700., 2820., 2940., 3060, \
                                          3180, 3330., 3420., 3540]


                height = [float(v) for v in height]
                wdd = [99999.9]*34
                wff = [99999.9]*34
                ww = [99999.9]*34
                cn2 = [99999.9]*34
        except:

            height = [120., 180., 240., 300.0, 360., 420., \
                                      480., 540., 600.0, 660., 780., 900., \
                                      1020., 1140., 1260., 1380., 1500., 1620, \
                                      1740., 1860., 1980., 2100., 220., 2340., \
                                      2460., 2580., 2700., 2820., 2940., 3060, \
                                      3180, 3330., 3420., 3540]

            wdd = [99999.9]*34
            wff = [99999.9]*34
            ww = [99999.9]*34
            cn2 = [99999.9]*34
            timeinfo = ''




        data = {'height':height,'wdd':wdd,'wff':wff,'ww':ww,'cn2':cn2,'timeinfo':timeinfo}
        return data

    def read_profiler_yq(self,file):
        '''
        读取海淀风廓线资料
        '''
        #file = r'Y:\vertical\profiler\HD_54399\wind\Z_RADR_I_54399_20100415063600_P_WPRD_LC_ROBS.TXT'
        try:
            f = open(file,'r')
            lines = f.readlines()
            f.close()
            #print lines
            #读取实际资料是从第4行开始到最后第二行
            lens = range(len(lines))#有效资料长度
            wdd = []
            wff = []
            ww = []
            cn2 = []
            height = []

            stime = (lines[1].split(' '))[-1]
            year = stime[0:4]
            month = stime[4:6]
            day = stime[6:8]
            hour = stime[8:10]
            minute = stime[10:12]
            #print 'year=',year,'month=',month,'day=',day,'hour=',hour,'minute=',minute

            tt1 = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
            tt2  = tt1 + datetime.timedelta(hours = 8)#世界时转化为北京时
            #sst = tt2.timetuple()
            timeinfo = str(tt2)
            for i in lens[3:-1]:
                #print i,lines[i]
                data = lines[i].split(' ')
                #print data
                try:
                    height.append(float(data[0]))
                except:
                    height.append(99999.9)
                try:
                    if float(data[1]) < 0.0 or float(data[1]) >360.0:
                        wdd.append(99999.9)
                    else:
                        wdd.append(float(data[1]))
                except:
                    wdd.append(99999.9)
                try:
                    if float(data[2]) < 0.0 or float(data[2]) > 100.0:
                        wff.append(99999.9)
                    else:
                        wff.append(float(data[2]))
                except:
                    wff.append(99999.9)
                try:
                    ww.append(float(data[3]))
                except:
                    ww.append(99999.9)
                try:
                    cn2.append(float(data[6]))
                except:
                    cn2.append(99999.9)

            if len(height) != 58:

                height = [150.0, 270.0, 390.0, 510.0, 630.0, 750.0, 870.0, 990.0, 1110.0, 1230.0, 1350.0, 1470.0, 1590.0, 1710.0, 1830.0, 1950.0, 2190.0, 2430.0, 2670.0, 2910.0, 3150.0, 3390.0, 3630.0, 3870.0, 4110.0, 4350.0, 4590.0, 4830.0, 5070.0, 5310.0, 5550.0, 5790.0, 6030.0, 6270.0, 6510.0, 6750.0, 6990.0, 7230.0, 7470.0, 7710.0, 7950.0, 8190.0, 8430.0, 8670.0, 8910.0, 9150.0, 9390.0, 9630.0, 9870.0, 10110.0, 10350.0, 10590.0, 10830.0, 11070.0, 11310.0, 11550.0, 11790.0, 12030.0]

                wdd = [99999.9]*58
                wff = [99999.9]*58
                ww = [99999.9]*58
                cn2 = [99999.9]*58
        except:
            height = [150.0, 270.0, 390.0, 510.0, 630.0, 750.0, 870.0, 990.0, 1110.0, 1230.0, 1350.0, 1470.0, 1590.0, 1710.0, 1830.0, 1950.0, 2190.0, 2430.0, 2670.0, 2910.0, 3150.0, 3390.0, 3630.0, 3870.0, 4110.0, 4350.0, 4590.0, 4830.0, 5070.0, 5310.0, 5550.0, 5790.0, 6030.0, 6270.0, 6510.0, 6750.0, 6990.0, 7230.0, 7470.0, 7710.0, 7950.0, 8190.0, 8430.0, 8670.0, 8910.0, 9150.0, 9390.0, 9630.0, 9870.0, 10110.0, 10350.0, 10590.0, 10830.0, 11070.0, 11310.0, 11550.0, 11790.0, 12030.0]

            wdd = [99999.9]*58
            wff = [99999.9]*58
            ww = [99999.9]*58
            cn2 = [99999.9]*58
            timeinfo = ''




        #print 'len of data ',len(height),np.max(height)
        #print 'height',height
        data = {'height':height,'wdd':wdd,'wff':wff,'ww':ww,'cn2':cn2,'timeinfo':timeinfo}
        return data

    def read_profiler_gxt(self,file):
        '''
        读取海淀风廓线资料
        '''
        #file = r'Y:\vertical\profiler\HD_54399\wind\Z_RADR_I_54399_20100415063600_P_WPRD_LC_ROBS.TXT'
        f = open(file,'r')
        lines = f.readlines()
        f.close()
        #print lines
        #读取实际资料是从第4行开始到最后第二行
        lens = range(len(lines))#有效资料长度
        wdd = []
        wff = []
        ww = []
        cn2 = []
        height = []

        stime = (lines[1].split(' '))[-1]
        year = stime[0:4]
        month = stime[4:6]
        day = stime[6:8]
        hour = stime[8:10]
        minute = stime[10:12]
        #print 'year=',year,'month=',month,'day=',day,'hour=',hour,'minute=',minute

        tt1 = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
        tt2  = tt1 + datetime.timedelta(hours = 8)#世界时转化为北京时
        #sst = tt2.timetuple()
        timeinfo = str(tt2)
        for i in lens[3:-1]:
            #print i,lines[i]
            data = lines[i].split(' ')
            try:
                height.append(float(data[0]))
            except:
                height.append(99999.9)
            try:
                if float(data[1]) < 0.0 or float(data[1]) >360.0:
                    wdd.append(99999.9)
                else:
                    wdd.append(float(data[1]))
            except:
                wdd.append(99999.9)
            try:
                if float(data[2]) < 0.0 or float(data[2]) > 100.0:
                    wff.append(99999.9)
                else:
                    wff.append(float(data[2]))
            except:
                wff.append(99999.9)
            try:
                ww.append(float(data[3]))
            except:
                ww.append(99999.9)
            try:
                cn2.append(float(data[6]))
            except:
                cn2.append(99999.9)
        print 'len of data ',len(height),np.max(height)
        if len(height) != 55:
            wdd = [99999.9]*55
            wff = [99999.9]*55
            ww = [99999.9]*55
            cn2 = [99999.9]*55
            height = [150.0, 270.0, 390.0, 510.0, 630.0, 750.0, 870.0, 990.0, 1110.0, 1230.0, 1350.0, 1470.0, 1590.0, 1710.0, 1830.0, 1950.0, 2070.0, 2190.0, 2310.0, 2430.0, 2550.0, 2790.0, 3030.0, 3270.0, 3510.0, 3750.0, 3990.0, 4230.0, 4470.0, 4710.0, 4950.0, 5430.0, 5910.0, 6390.0, 6870.0, 7350.0, 7830.0, 8310.0, 8790.0, 9270.0, 9750.0, 10230.0, 10710.0, 11190.0, 11670.0, 12150.0, 12630.0, 13110.0, 13590.0, 14070.0, 14550.0, 15030.0, 15510.0, 15990.0, 16470.0]

        #print 'len of data ',len(height),np.max(height)
        #print 'height',height
        data = {'height':height,'wdd':wdd,'wff':wff,'ww':ww,'cn2':cn2,'timeinfo':timeinfo}
        return data

    def read_profiler_sdz(self,file):
        '''
        读取上甸子资料
        '''
        # print file
        #file = r'Y:\vertical\profiler\HD_54399\wind\Z_RADR_I_54399_20100415063600_P_WPRD_LC_ROBS.TXT'
        f = open(file,'r')
        lines = f.readlines()
        # print 'lines',lines
        f.close()
        #print lines
        #读取实际资料是从第4行开始到最后第二行
        lens = range(len(lines))#有效资料长度
        # print 'lens',lens
        wdd = []
        wff = []
        ww = []
        cn2 = []
        height = []
        #Wg_sdz20100831103223.txt
        stime = os.path.basename(file)[15:]#将6改成了15
        # print stime
        year = stime[0:4]
        month = stime[4:6]
        day = stime[6:8]
        hour = stime[8:10]
        minute = stime[10:12]
        #print 'year=',year,'month=',month,'day=',day,'hour=',hour,'minute=',minute

        tt1 = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
        #tt2  = tt1 + datetime.timedelta(hours = 8)#世界时转化为北京时
        #sst = tt2.timetuple()
        timeinfo = str(tt1)
        print 'timeinfo=',timeinfo
        for i in lens[8:-1]:
            # print i,lines[i]
            data = lines[i].split(' ')#我把逗号改成了空格
            # print 'data[1]::',data[1]
            # print type(data[0])

            try:
                height.append(float(data[0])*1000.)
                # print('data[0]:!!!!!',data[0])
                # print 'height',height
            except:
                height.append(99999.9)
                # print 'height',height
            try:
                if float(data[2]) < 0.0 or float(data[2]) >360.0:
                    wdd.append(99999.9)
                else:
                    wdd.append(float(data[2]))
            except:
                wdd.append(99999.9)
            try:
                if float(data[1]) < 0.0 or float(data[1]) > 360.0:#问题出在这里
                    wff.append(99999.9)
                else:
                    wff.append(float(data[1]))
            except:
                wff.append(99999.9)
            try:
                ww.append(99999.9)
            except:
                ww.append(99999.9)
            try:
                cn2.append(99999.9)
            except:
                cn2.append(99999.9)
        # print 'len of data ',len(height),np.max(height)

        data = {'height':height,'wdd':wdd,'wff':wff,'ww':ww,'cn2':cn2,'timeinfo':timeinfo}
        # print('data>>>>>>>>>>',data)
        return data

    def read_profiler_gxt_old(self,file):
        '''
        convert  the old format (obs format) windprofiler dataset to new format
        '''

        f = open(file,'r')
        lines = f.readlines()
        f.close()

        lens = range(len(lines))#有效资料长度
        wdd = []
        wff = []
        ww = []
        cn2 = []
        height = []
        #print lines[20]
        #print lines[21]
        stime1 = lines[20].split(':')
        #print 'stime1=',stime1[-1]
        year = stime1[-1].split('-')[0]
        month = stime1[-1].split('-')[1]
        day = stime1[-1].split('-')[2]
        #print 'year=',year
        t1 = ('').join(stime1[-1].split('-'))
        #print t1
        stime2 = lines[21].split(' ')
        #print stime2[-1]
        t2 = stime2[-1][0:2]+stime2[-1][3:5]
        #print t2
        timeinfo = t1[:-1]+t2
        #print 'timeinfo',timeinfo
        for line in lines:
            if line[0:1] == '+':
                data = [v for v in line.split(' ') if v!='']
                #print data
                try:
                    height.append(float(data[1]))
                except:
                    height.append(99999.9)
                try:
                    if float(data[3]) < 0.0 or float(data[3]) >360.0:
                        wdd.append(99999.9)
                    else:
                        wdd.append(float(data[3]))
                except:
                    wdd.append(99999.9)
                try:
                    if float(data[2]) < 0.0 or float(data[2]) > 100.0:
                        wff.append(99999.9)
                    else:
                        wff.append(float(data[2]))
                except:
                    wff.append(99999.9)
                try:
                    ww.append(float(data[4]))
                except:
                    ww.append(99999.9)
                try:
                    cn2.append(float(data[5]))
                except:
                    cn2.append(99999.9)

        data = {'height':height,'wdd':wdd,'wff':wff,'ww':ww,'cn2':cn2,'timeinfo':timeinfo}
        return data

    def read_profiler_zb_nc(self,file):
        #file = r'V:\vips\data\windprofiler\zb\WPRD_W_ROBS_53399_20100823031735.nc'
        f= Dataset(file,'r')

        wdd = f.variables['wdh'][:]
        wff = f.variables['wsh'][:]
        ww = f.variables['wsv'][:]
        cn2 = f.variables['wdvCN2'][:]
        height = f.variables['hh'][:]

        #时间信息
        sst = os.path.basename(file)[-17:]
        year = sst[0:4]
        month = sst[4:6]
        day=sst[6:8]
        hour = sst[8:10]
        minute = sst[10:12]
        tt1 = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
        tt2  = tt1 + datetime.timedelta(hours = 8)#世界时转化为北京时
        timeinfo = str(tt2)

        mask = np.where(np.logical_and(wdd <0,wdd>360))
        wdd[mask]=  99999.9
        mask = np.where(np.logical_and(wff <0,wff>100))
        wff[mask]=  99999.9
        mask = np.where(ww>100)
        ww[mask]=  99999.9
        mask = np.where(cn2>1000)
        cn2[mask]=  99999.9

        mask = np.where(height>10000)
        height[mask]=  99999.9

        data = {'height':height.tolist(),'wdd':wdd.tolist(),'wff':wff.tolist(),'ww':ww.tolist(),'cn2':cn2.tolist(),'timeinfo':timeinfo}
        return data

    def windbarb2(self,ax,x,y,u,v,wff,sid='hd',**kc):
        '''
        在x,y坐标上画风向标
        '''


        #x = np.linspace(-5, 5, 5)
        X,Y = x,y
        #U, V = 12*X, 12*Y
        U,V = u,v
        U1=U.copy() #画0-8m/s的风向标(color='#000000')
        U2=U.copy()#画8-12m/s的风向标(color='#0000FF')
        U3=U.copy()#画12-17m/s的风向标(color='#00FF00')
        U4=U.copy()#画17-25m/s的风向标(color='#FF0000')
        U5=U.copy()#画>=25m/s的风向标(color='#9900FF')
        U1[np.where(wff >8.0)]=np.nan
        ax.barbs(X, Y, U1, V,length=5,fill_empty=False,barbcolor='#000000',\
                 sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20),**kc)
        U2[np.where(wff <=8.0)]=np.nan
        U2[np.where(wff >12.0)]=np.nan
        ax.barbs(X, Y, U2, V,length=5,fill_empty=False,barbcolor='#000000',\
                 sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20),**kc)

        U3[np.where(wff <=12.0)]=np.nan
        U3[np.where(wff >17.0)]=np.nan
        ax.barbs(X, Y, U3, V,length=5,fill_empty=False,barbcolor='#000000',\
                 sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20),**kc)

        U4[np.where(wff <=17.0)]=np.nan
        U4[np.where(wff >25.0)]=np.nan
        ax.barbs(X, Y, U4, V,length=5,fill_empty=False,barbcolor='#000000',\
                 sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20),**kc)

        U5[np.where(wff <=25.0)]=np.nan

        ax.barbs(X, Y, U5, V,length=5,fill_empty=False,barbcolor='#000000',\
                 sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20),**kc)

        #保存图片，每张图片显示35个时刻

        leny,lenx = u.shape
        '''
        print 'lenx,leny =',lenx,leny
        if sid=='hd':
            text(20, 20, "Beijing Weather", fontsize=46,alpha=0.6,rotation=0,horizontalalignment='center')
        if sid=='yq':
            text(20, 30, "Beijing Weather", fontsize=46,alpha=0.6,rotation=0,horizontalalignment='center')

        if sid=='zb':
            text(20, 18, "Beijing Weather", fontsize=46,alpha=0.6,rotation=0,horizontalalignment='center')
        '''



        #判断需要画多少张图
        #subplots_adjust(left=0.0,right=1.0,bottom=0.1,top=0.9)
        #ax.axis([0,leny,0,lenx])
        #plt.savefig('out.png',transparent=True)




        #print 'xmin, xmax ',xmin, xmax
        #plt.axis([0,25,0,36])

        #plt.savefig('1.png',transparent=True)

    def get_filename(self,year,month,day,hour,minute,interv=6,num=30):
        '''
        根据给定的时间年月日时分和数据的间隔6/12/18...
        生成所要读取的风廓线资料文件对应的时间
        注意这里输入的时间是北京时间，但风廓线文件对应的时间是世界时
        interv 为资料的间隔时间，必须为6的整数倍
        num 为需要求算的时间个数，一般对应于将要读取的文件个数，默认为３０个
        返回一个时间字符串列表
        '''
        s1 =  datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
        #print 'input time(bj):',s1
        filestime_bj = []
        for i in range(num):
            ss =  s1 + datetime.timedelta(minutes = -int(interv)*i)
            #print 'the time is ',ss
            ss = ss.timetuple()
            filestime_bj.append(str(ss[0])+(str(ss[1])).zfill(2)+(str(ss[2])).zfill(2)+(str(ss[3])).zfill(2)+(str(ss[4])).zfill(2)+'00')

        starttime=filestime_bj[-1]
        endtime=filestime_bj[0]
        ####  返回给微波辐射计的起始时间是北京时！！！####

        s2 = s1 + datetime.timedelta(hours = -8) #北京时间转化为世界时间
        #print 'input time(utc):',s2
        filestime = []
        for i in range(num):
            ss =  s2 + datetime.timedelta(minutes = -int(interv)*i)
            #print 'the time is ',ss
            ss = ss.timetuple()
            filestime.append(str(ss[0])+(str(ss[1])).zfill(2)+(str(ss[2])).zfill(2)+(str(ss[3])).zfill(2)+(str(ss[4])).zfill(2)+'00')

        #print 'the filestime is(utc) ',filestime

        return filestime,starttime,endtime

    def get_filename_nc(self,year,month,day,hour,minute,interv=6,num=30):
        '''
        根据给定的时间年月日时分和数据的间隔6/12/18...
        生成所要读取的风廓线资料文件对应的时间
        注意这里输入的时间是北京时间，但风廓线文件对应的时间是世界时
        interv 为资料的间隔时间，必须为6的整数倍
        num 为需要求算的时间个数，一般对应于将要读取的文件个数，默认为３０个
        返回一个时间字符串列表
        '''
        s1 =  datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
        #print 'input time(bj):',s1
        s2 = s1 + datetime.timedelta(hours = -8) #北京时间转化为世界时间
        #print 'input time(utc):',s2

        filestime = []
        for i in range(num):
            ss =  s2 + datetime.timedelta(minutes = -int(interv)*i)
            #print 'the time is ',ss
            ss = ss.timetuple()
            filestime.append(str(ss[0])+(str(ss[1])).zfill(2)+(str(ss[2])).zfill(2)+(str(ss[3])).zfill(2)+(str(ss[4])).zfill(2))

        #print 'the filestime is(utc) ',filestime


        return filestime

    def height2pressure(self,height):
        '''
        input height should be np.array
        '''
        Ro=6371.3*1000.0
        local_latitude=np.deg2rad(40)
        a=9.80616*(1-0.00259*cos(2*local_latitude))/9.80665
        b=Ro*(1+height/Ro)**2*(height)/(Ro+height)
        Z=a*b

        c=(44331.0-Z)/44331.0
        #pressure=1013.255*c^(1.0/0.1903)
        #print,pressure
        pressure = 1013.255 * 10.0**(np.log10(c)*(1.0/0.1903))
        return pressure
    def temp_tad(self,wff,wdd,pressure):
        '''计算温度平流'''
        print 'shape of wff',wff.shape
        print 'shape of pressure',pressure.shape
        size = pressure.shape
        p1 = pressure.copy()
        p2 = pressure[:,1:]
        p2 = np.append(p2,pressure[:,0])
        p2.shape = size
        print 'p1[1] ',p1[0,:]
        print 'p2[0] ',p2[0,:]
        wff1 = wff.copy()
        wff2 = wff[:,1:]
        print 'wff1',wff1[0]
        print 'wff',wff[0]
        wff2 = np.append(wff2,wff[:,0])
        wff2.shape = size
        print 'wff1[1]',wff1[0,:]
        print 'wff2[0]',wff2[0]
        wdd1 = wdd
        wdd2 = wdd[:,1:]
        wdd2 = np.append(wdd2,wdd[:,0])
        wdd2.shape = size

        print 'wdd1',wdd1[0]
        print 'wdd2',wdd2[0]
        rd=287.0#8.3145
        f=2*7.292e-5*np.sin(np.deg2rad(40))

        tad= - 0.5*(p1+p2)*f/(rd*(p1-p2))*wff1*wff2*np.sin(np.deg2rad(wdd1-wdd2))
        tad[:,-1] = np.nan
        tad.shape = size
        #print 'tad [0]',tad[3]
        #tad =((p1-p2))

        return tad

    def temp_tad2(self,wff,wdd,pressure):
        size =  pressure.shape
        print 'size = ',size
        #rd=8.3145
        rd=287.0
        f=2*7.292e-5*np.sin(np.deg2rad(40))#deg2rad度变角度
        tt = []
        for j in range(size[0]):
            p = pressure[j]
            ff = wff[j]
            dd = wdd[j]
            for i in range(size[1]-1):
                #print 'p[1]-p[i+1]',p[1]-p[i+1]
                #print 'dd[i]-dd[i+1]',dd[i]-dd[i+1]
                tad= - 0.5*(p[i]+p[i+1])*f/(rd*(p[1]-p[i+1]))*ff[i]*ff[i+1]*np.sin(np.deg2rad(dd[i]-dd[i+1]))
                tt.append(tad)
            tt.append(99999.0)
        print 'len of tt',len(tt)

        tt0 = np.array(tt)
        tt0[np.where(tt0 == 99999.0)]=np.nan
        tt0.shape= size

        print 'max tt0',np.nanmax(tt0)
        print 'min tt0',np.nanmin(tt0)
        return tt0

    def low_lev_jet(self,wff,height):
        '''
        计算低空急流
        3km以下大于12m/s的风速为低空急流
        '''
        print 'in low_lev_jet'

        (i,j) =  np.where(height > 3000.0)
        wff1 =wff.copy()
        wff1[i,j] = np.nan
        #print 'wff1',wff1
        #print wff1.shape
        #判断是否有低空急流促存在
        wff1[np.where(wff1 < 12.0)] = np.nan
        #print 'wff1 again',wff1
        return wff1

    def vetical_wshear(self,wff):
        '''
        计算风垂直切变
        v/vo = (h/h0)**apha
        计算1-3km厚度内的平均垂直风切变
        '''
        pass

    def gradient_windspeed(self,wff,height):
        '''
        计算风速场的梯度
        '''
        wff1 = wff.copy()
        hh1 = height.copy()
        wff1 =  np.gradient(wff1)
        hh1 =  np.gradient(hh1)
        print wff1[0]
        #return wff1

    def vorticity(self,uu,vv):
        #wff[np.where(wff < 1.0)] = 1.0
        #uu = -wff*np.sin(np.deg2rad(wdd))
        #vv = -wff*np.cos(np.deg2rad(wdd))

        (div,vor)=convergence_vorticity(uu,vv,1,1)
        return vor

    def moment(self,wff,ww):
        '''
        计算动量p=mv
        '''
        p = (wff+ np.abs(ww))#*(ww/np.abs(ww))
        mask = np.where(ww < 0.0)
        p[mask] = -1.0*p[mask]
        return p

if __name__=="__main__":
    print '----run profiler python pro----'
    windprofiler = windprofiler()
    #files = glob.glob(r'\\10.224.97.22\micaps\vertical\profiler\HD_54399\wind\*.TXT')
    #files.sort()
    #r=windprofiler.get_filename('2010','04','22','21','06',interv=6,num=30)


    data=windprofiler.read_profiler_sdz(r'C:\D\project\windprofiler_0808_250\data\windprofiler\Z_RADA_I_54511_20171120231800_P_WPRD_LC_ROBS.TXT')
    print data['height']
    #
