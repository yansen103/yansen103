#! /usr/bin/env python
#coding=utf-8
import os,sys
try:
    os.system(r'F:\nowcast_yewu\windprofiler_0808\hd_profiler_auto.py')
    print 'deal hd over'
except:
    pass



try:
    os.system(r'F:\nowcast_yewu\windprofiler_0808\yq_profiler_auto.py')
    print 'deal yq over'
except:
    pass
try:
    os.system(r'F:\nowcast_yewu\windprofiler_0808\zb_profiler_history.py')
    print 'deal zb over'
except:
    pass
try:
    os.system(r'F:\nowcast_yewu\windprofiler_0808\ts_profiler_history.py')
    print 'deal zb over'
except:
    pass
try:
    os.system(r'F:\nowcast_yewu\windprofiler_0808\sdz.py')
    print 'deal sdz over'
except:
    pass
