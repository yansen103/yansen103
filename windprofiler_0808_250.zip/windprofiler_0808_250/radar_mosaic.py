#! /usr/bin/env python
#coding=utf-8
from netCDF4  import Dataset
import numpy as np
from windprofiler import windprofiler
import matplotlib.pyplot as plt
from matplotlib import *
from pylab import *
import datetime,string
import ConfigParser,os,sys
config=ConfigParser.ConfigParser()
   


def read_radar_mosaic(files):
    '''
    read one point data of radar mosaic
    '''
    in_lon = 116.2908
    in_lat = 39.9869
    index_lon = 460
    index_lat = 464
    for file in files:
        f= Dataset(r'C:\mywork\code\idl\bj_nowcast\testdata\mosaic\0908061000.nc','r')
        print f.variables
        
        #-----确定输入的经度纬度在数据中对应的位置,index_lon,index_lat
        print f.variables
        lon = f.variables['longtitude'][:]
        lat = f.variables['latitude'][:]
        min_diff_lon = np.min(abs(lon - in_lon))
        print 'min_diff_lon=',min_diff_lon
        index_lon = np.where(abs(lon - in_lon) == min_diff_lon)
        print 'index_lon=',index_lon,'lon=',lon[index_lon],'face lon=',in_lon
        min_diff_lat = np.min(abs(lat - in_lat))
        print 'min_diff_lat=',min_diff_lat
        index_lat = np.where(abs(lat - in_lat) == min_diff_lat)
        print 'index_lat=',index_lat,'lat=',lat[index_lat],'face lat=',in_lat
        layer = f.variables['layer'][:]
        print 'layer=',layer
        #--------------------------------------------------------------------
        print 'dimension of variables'
        print 'longitude ',lon.shape
        print 'latitude ',lat.shape
        reflec = f.variables['reflectivity'][:,:,:]
        #---------方法一：还原的-128 - 127 
        '''
        reflec1 = (reflec +33)*2.0
        #(i,j) = np.where(reflec1 < 0)
        reflec1[np.where(reflec1 < 0.)] = reflec1[np.where(reflec1 < 0.)]+256.
        #--把-128-128===>0 - 255
        dbz = (reflec1)*0.5 -33 
        dbz[np.where(dbz<0)] = np.nan
        print 'last'
        print 'max dbz=',np.nanmax(dbz)
        print 'min dbz=',np.nanmin(dbz)
        '''
        #----------------------------------
        #------方法二：-------------
        reflec[np.where(reflec < -33.)] = ((reflec[np.where(reflec < -33.)]+33.)*2.0+256.)*0.5 - 33
        reflec[np.where(reflec<0)] = np.nan
        print 'last2'
        print 'max dbz=',np.nanmax(reflec)
        print 'min dbz=',np.nanmin(reflec)
        
        maxdbz = np.nanmax(reflec,axis = 0)

        
        
        
        
def read_radar_mosaic_point(files,station = '54399'):
    '''
    read one point data of radar mosaic
    '''
    #hd
    if station == '54399':
        #in_lon = 116.2908
        #in_lat = 39.9869
        index_lon = [460]
        index_lat = [464]
        

    
    #yq
    #in_lon = 115.9688	
    #in_lat = 40.4493
    if station == '54406':
        index_lon = [427]
        index_lat = [510]
        

    

    point_dbz = []
    for file in files:
        try:
            
            print 'try to read ',file
            f= Dataset(file,'r')
                    
            #-----确定输入的经度纬度在数据中对应的位置,index_lon,index_lat
            '''
            lon = f.variables['longtitude'][:]
            lat = f.variables['latitude'][:]
            min_diff_lon = np.min(abs(lon - in_lon))
            print 'min_diff_lon=',min_diff_lon
            index_lon = np.where(abs(lon - in_lon) == min_diff_lon)
            print 'index_lon=',index_lon,'lon=',lon[index_lon],'face lon=',in_lon
            min_diff_lat = np.min(abs(lat - in_lat))
            print 'min_diff_lat=',min_diff_lat
            index_lat = np.where(abs(lat - in_lat) == min_diff_lat)
            print 'index_lat=',index_lat,'lat=',lat[index_lat],'face lat=',in_lat
            
            '''
            lon = f.variables['longtitude'][:]
            lat = f.variables['latitude'][:]
            #layer =  f.variables['layer'][:]
            np.save('mosaic_lon',lon)
            np.save('mosaic_lat',lat)
            reflec = f.variables['reflectivity'][:,index_lat[0],index_lon[0]]
            print 'reflec=',np.min(reflec),np.max(reflec)
            #print 'reflec=',reflec
            #---------方法一：还原的-128 - 127 
            '''
            reflec1 = (reflec +33)*2.0
            #(i,j) = np.where(reflec1 < 0)
            reflec1[np.where(reflec1 < 0.)] = reflec1[np.where(reflec1 < 0.)]+256.
            #--把-128-128===>0 - 255
            dbz = (reflec1)*0.5 -33 
            dbz[np.where(dbz<0)] = np.nan
            print 'last'
            print 'max dbz=',np.nanmax(dbz)
            print 'min dbz=',np.nanmin(dbz)
            '''
            #----------------------------------
            
            #------方法二：-------------
            
            '''
            reflec[np.where(reflec < -33.)] = ((reflec[np.where(reflec < -33.)]+33.)*2.0+256.)*0.5 - 33
            
            reflec[np.where(reflec<0)] = np.nan
            '''

            point_dbz.append(reflec.tolist())
            #print 'max dbz=',np.nanmax(reflec)
            #print 'min dbz=',np.nanmin(reflec)
            
        except:
            vv =  np.array([np.nan]*20)
            point_dbz.append(vv.tolist())
            pass
            

    #np.save('E:\mywork\mysite\profiler2\mosaic_layer',layer)
    #np.save('E:\mywork\mysite\profiler2\mosaic_lon',lon)
    #np.save('E:\mywork\mysite\profiler2\mosaic_lat',lat)
    point_dbz = np.array(point_dbz)
    point_dbz = np.transpose(point_dbz)
    return point_dbz



def match_time_mosaic(start_time,end_time):
    '''
    根据风廓线文件的时间，找到最接近或对应的雷达资料文件
    '''
    st = start_time.timetuple()#风廓线起始时间

    
    s1 = start_time 
    mosaic_time_list = []
    mosaic_time_list.append(s1)

    while 1:
        s2 = s1 +datetime.timedelta(minutes = -6)
        
        
        s1 =  s2
        if s2 < end_time:
            break
        else:
            mosaic_time_list.append(s2)
    
    
    return mosaic_time_list

    

        
        
def draw_point_dbz_seriers(dbz,timeinfo,title,height_limit=[0,10000.0],outpic = 'mosaic.png',**kc):
    left, width = 0.1, 0.75
    bottom, height = 0.1, 0.85
    bottom_h = bottom+height
    left_h = left+width
    rect_scatter = [left, bottom, width, height]
    rect_notes = [left_h, bottom, 0.13, height]
    nullfmt   = NullFormatter()
    fig = plt.figure(figsize=(12,8))
    ax = plt.axes(rect_scatter)
    #cs = ax.contourf(dbz,range(5,80,5))
    cs =imshow(dbz, interpolation='nearest',**kc)
    
    ylim(-0.54,5)
    myticks = range(10)
    myticks = [v*3 for v in myticks]
    mylabels =[]
    mylabels = ['']*10
    plt.xticks(myticks,mylabels,rotation=30,size=13,weight='bold')
    ax.yaxis.set_major_formatter(nullfmt)
    axnotes = plt.axes(rect_notes)
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)
    
    cax = plt.axes([0.88,0.3,0.03,0.4])
    plt.colorbar(cs,cax=cax,extend="both")
    axnotes.text(1,25,title,verticalalignment='center',rotation=90)        
    axnotes.axis([0,12,0,50])
    
    
    #plt.show()
    plt.savefig(outpic,transparent=True,dpi=100)
            
            
def draw_point_dbz_seriers_yq(dbz,timeinfo,title,height_limit=[0,10000.0],outpic = 'mosaic.png',**kc):
    left, width = 0.1, 0.75
    bottom, height = 0.1, 0.85
    bottom_h = bottom+height
    left_h = left+width
    rect_scatter = [left, bottom, width, height]
    rect_notes = [left_h, bottom, 0.13, height]
    nullfmt   = NullFormatter()
    fig = plt.figure(figsize=(12,12))
    ax = plt.axes(rect_scatter)
    #cs = ax.contourf(dbz,range(5,80,5))
    cs =imshow(dbz, interpolation='nearest',**kc)
    
    ylim(-0.54,5)
    myticks = range(10)
    myticks = [v*3 for v in myticks]
    mylabels =[]
    mylabels = ['']*10
    plt.xticks(myticks,mylabels,rotation=30,size=13,weight='bold')
    ax.yaxis.set_major_formatter(nullfmt)
    axnotes = plt.axes(rect_notes)
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)
    
    cax = plt.axes([0.88,0.3,0.03,0.4])
    plt.colorbar(cs,cax=cax,extend="both")
    axnotes.text(1,25,title,verticalalignment='center',rotation=90)        
    axnotes.axis([0,12,0,50])
    
    
    #plt.show()
    plt.savefig(outpic,transparent=True,dpi=100)


        
        
    
    
    
    
if __name__ == '__main__':
    '''
    current_path = 'C:/mywork/code/profiler'
    config.readfp(open(current_path+'/ini.cfg','r'))  
    mosaic_indir = config.get('mosaic','indir')        
    mosaic_outdir = config.get('mosaic','outdir')


    windprofiler = windprofiler()

    
    filestime = windprofiler.get_filename(year,month,day,hour,minute,interv=inteval,num=30)
    files = [mosaic_indir+'\\'+v[2:-2]+'.nc' for v in filestime]
    print files
    afile = [r'C:\mywork\code\idl\bj_nowcast\testdata\0907301530.nc']
    '''
    file = r'X:\vips\data\mosaic\1006080236.nc'
    f= Dataset(file,'r')
   
    lon = f.variables['longtitude'][:]
    lat = f.variables['latitude'][:]
    #layer =  f.variables['layer'][:]
    #np.save('mosaic_lon',lon)
    #np.save('mosaic_lat',lat)
    index_lon = [460]
    index_lat = [464]

    reflec = f.variables['reflectivity'][:,index_lat[0],index_lon[0]]
    print reflec
 
    #----------------------------
    files=[r'X:\vips\data\mosaic\1006080236.nc']
    read_radar_mosaic_point(files,station = '54399')
