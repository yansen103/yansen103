#! /usr/bin/env python
#coding=utf-8
#import numpy as np
#import matplotlib.pyplot as plt
#from matplotlib.ticker import NullFormatter
from windprofiler import windprofiler
#import glob
#from matplotlib import mpl
#from pylab import *
import datetime,os,sys
#from match_time_aws_profiler import *
#from radar_mosaic import *
#from interp_2d import wgr_congrid
#from profile_index  import wind_shear,jet_index,draw_index
import subprocess
import ConfigParser,os,sys,string
config=ConfigParser.ConfigParser()

'''
自动生成最新的风阔线图形
'''
current_path =  os.getcwd()#string.replace(os.path.dirname(__file__),'\\','/')
config.readfp(open(current_path+'/his_ini.cfg','r+'))  
indir = config.get('yq','indir')
print '数据文件目录:',indir
files = os.listdir(indir)
files.sort()
files.reverse()
#print files[0]
tt = files[0].split('_')[4]
year = tt[0:4]
month = tt[4:6]
day = tt[6:8]
hour = tt[8:10]
minute = tt[10:12]

#print year,month,day,hour,minute
st = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
sst = st + datetime.timedelta(hours=8)
ss = sst.timetuple()
year = ss[0]
month = ss[1]
day = ss[2]
hour = ss[3]
minute = ss[4]
inteval = 6
#config.readfp(open(current_path+'/his_ini.cfg','r')) 
f= open(current_path+'/his_ini.cfg',"r+")

_year = config.get('yq','year')
_month = config.get('yq','month')
_day = config.get('yq','day')
_hour = config.get('yq','hour')
_minute = config.get('yq','minute')
_inteval = config.get('yq','inteval')
f.close()
#print 'get inteval',inteval
t1 = datetime.datetime(year,month,day,hour,minute)
t0 = datetime.datetime(int(_year),int(_month),int(_day),int(_hour),int(_minute))
dd = t1 - t0
#for inteval in [6,12,30,60]
for inteval in [12,30]:
    f= open(current_path+'/his_ini.cfg',"r+")
    if 1:#((dd.days*86400 + dd.seconds) / 60.0 > 15.0):
        
        config.set('yq','year',year)
        config.set('yq','month',month)
        config.set('yq','day',day)
        config.set('yq','hour',hour)
        config.set('yq','minute',minute)
        config.set('yq','inteval',inteval)    
        config.write(f)
        
        subprocess.call(current_path+'\\yq_profiler_history.py',shell=True)
        subprocess.call(current_path+'\\radiometric_windprofiler_54406.py',shell=True)

    f.close()

f.close()
