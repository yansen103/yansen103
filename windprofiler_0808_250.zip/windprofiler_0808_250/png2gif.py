#! /usr/bin/env python
#coding=utf-8
import os

from PIL import Image


def png2gif(infile,outfile):
    try:
        im = Image.open(infile)
        alpha = im.split()[3]
        # Convert the image into P mode but only use 255 colors in the palette out of 256
        im = im.convert('RGB').convert('P', palette=Image.ADAPTIVE, colors=255)
        # Set all pixel values below 128 to 255,
        # and the rest to 0
        mask = Image.eval(alpha, lambda a: 255 if a <=128 else 0)
        # Paste the color of index 255 and use alpha as a mask
        im.paste(255, mask)
        # The transparency index is 255
        #im.save('mouse.gif', transparency=255)

        #im = im.convert('RGB').convert('P', palette=Image.ADAPTIVE)
        im.save(outfile, transparency=255)
        os.remove(infile)
    except:
        pass
