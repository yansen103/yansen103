#! /usr/bin/env python
# coding=utf-8

import ConfigParser
import datetime
import glob
import os
import string
import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import *
from matplotlib.ticker import NullFormatter
from mpl_toolkits import *
from pylab import *

from match_time_aws_profiler import *
from png2gif import png2gif
#from interp_2d import wgr_congrid
from profile_index import draw_index, jet_index, wind_shear
from radar_mosaic import *
from windprofiler import windprofiler

config = ConfigParser.ConfigParser()


def draw_windbarb(xx, yy, uu, vv, wff, savepic='1.png'):
    # start with a rectangular Figure
    fig1 = plt.figure(figsize=(12, 8))
    print 'there is in draw_windbarb'
    axScatter = plt.axes(rect_scatter)
    windprofiler.windbarb2(axScatter, xx, yy, uu, vv, wff, sid='zb')
    size = uu.shape
    print 'the shape of uu is', size, [0, size[0], 0, size[1] + 1]
    axScatter.axis([0, size[0], 0, size[1] + 1])

    myticks = range(14)
    myticks = [v * 3 for v in myticks]
    mylabels = []
    mylabels = [timeinfo[v][5:16] for v in myticks]
    plt.xticks(myticks, mylabels, rotation=30, size=9, weight='bold')

    myticks = range(10)
    myticks = [v * 3 for v in myticks]
    mylabels = []
    # print 'height############',(height[0][myticks]).tolist()
    mylabels = [str(int(v + 293)) for v in (height[0][myticks]).tolist()]
    plt.yticks(myticks, mylabels, rotation=0, size=8, weight='bold')

    '''
    myticks = range(11)
    myticks = [v*3+1 for v in myticks]
    labels = [ str(int(v)) for v in (pressure[0][myticks]).tolist()]
    for ii in range(11):
        axScatter.text(-2,myticks[ii],labels[ii],rotation=30,size=9,weight='bold',color='r')

    axScatter.text(-3,size[1]+1,'hPa',size=10,weight='bold',color='r')
    '''
    axScatter.text(-1, size[1] + 1, 'm', size=10, weight='bold')

    #------------------------------------------------
    axnotes = plt.axes(rect_notes)

    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)

    axnotes.barbs(4, 1, 8, 0, length=5, fill_empty=False, barbcolor='#000000',
                  sizes=dict(emptybarb=0.2, spacing=0.20), barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5, 1, '0-8m/s', fontsize=8, weight='bold')
    axnotes.barbs(4, 3, 12, 0, length=5, fill_empty=False, barbcolor='#0000FF',
                  sizes=dict(emptybarb=0.2, spacing=0.20), barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5, 3, '8-12m/s', fontsize=8, weight='bold')

    axnotes.barbs(4, 5, 17, 0, length=5, fill_empty=False, barbcolor='#00FF00',
                  sizes=dict(emptybarb=0.2, spacing=0.20), barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5, 5, '12-17m/s', fontsize=8, weight='bold')
    axnotes.barbs(4, 7, 25, 0, length=5, fill_empty=False, barbcolor='#FF0000',
                  sizes=dict(emptybarb=0.2, spacing=0.20), barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5, 7, '17-25m/s', fontsize=8, weight='bold')
    axnotes.barbs(4, 9, 30, 0, length=5, fill_empty=False, barbcolor='#9900FF',
                  sizes=dict(emptybarb=0.2, spacing=0.20), barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5, 9, '>25m/s', fontsize=8, weight='bold')

    axnotes.text(6, 48, 'SDZ', size=8, weight='bold', horizontalalignment='center')
    axnotes.text(6, 45, 'Sea level:293m', size=7, weight='bold', horizontalalignment='center')
    axnotes.axis([0, 14, 0, 50])
    fig1.savefig(savepic, transparent=True, dpi=100)
    # plt.show()


def draw_pcolor(x, y, ww, levels=[0, 5], title='title', savepic='savepic.png', cb_fmt='%.2f', **kc):
    #---pic2-----
    print levels
    rcParams['xtick.labelsize'] = 9.0
    rcParams['ytick.labelsize'] = 9.0

    fig = plt.figure(figsize=(12, 8))
    z = ww.copy()
    z = np.transpose(z)
    size = z.shape

    print 'this is in draw pcolor '
    print 'the shape of z is', size
    axScatter = plt.axes(rect_scatter)
    cs = imshow(z, interpolation='nearest', **kc)
    #levels = arange(-30,30)
    # cs2=contour(z,[0.0,],colors='k')
    cs2 = contour(z, colors='k', linewidths=1.0)
    plt.clabel(cs2, inline=True, fmt='%.1f', fontsize=10)

    axScatter.axis([0, size[1], 0, size[0] + 1])

    myticks = range(14)
    myticks = [v * 3 for v in myticks]
    mylabels = []
    mylabels = [timeinfo[v][5:16] for v in myticks]
    plt.xticks(myticks, mylabels, rotation=30, size=9, weight='bold')

    myticks = range(10)
    myticks = [v * 3 for v in myticks]
    mylabels = []

    mylabels = [str(int(v + 1393)) for v in (height[0][myticks]).tolist()]
    plt.yticks(myticks, mylabels, rotation=0, size=8, weight='bold')
    '''
    myticks = range(11)
    myticks = [v*3+1 for v in myticks]
    labels = [ str(int(v)) for v in (pressure[0][myticks]).tolist()]
    for ii in range(11):
        axScatter.text(-2,myticks[ii],labels[ii],rotation=30,size=9,weight='bold',color='r')

    axScatter.text(-3,size[0]+1,'hPa',size=10,weight='bold',color='r')
    '''
    axScatter.text(-1, size[0] + 1, 'm', size=10, weight='bold')

    #------------------------------------------------
    axnotes = plt.axes(rect_notes)
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)

    # no labels

    cax = plt.axes([0.88, 0.3, 0.03, 0.4])

    plt.colorbar(cs, format=cb_fmt, cax=cax, extend="both")
    # title

    axnotes.text(1, 25, title, verticalalignment='center', rotation=90)
    axnotes.axis([0, 14, 0, 50])
    # axnotes.text(6,48,'HD(54399)',size=8,weight='bold',horizontalalignment='center')
    fig.savefig(savepic, transparent=True, dpi=100)


current_path = string.replace(os.path.dirname(__file__), '\\', '/')
print "currentpath#############", current_path


nullfmt = NullFormatter()         # no labels
# definitions for the axes
left, width = 0.05, 0.8
bottom, height = 0.1, 0.88
bottom_h = bottom + height
left_h = left + width
rect_scatter = [left, bottom, width, height]
rect_notes = [left_h, bottom, 0.13, height]


# the scatter plot:
windprofiler = windprofiler()
# print 'indir=',indir
nc_files = glob.glob(r'C:\D\project\windprofiler_0808_250\data\windprofiler\*.txt')
nc_files.sort()
nc_files.reverse()
outdir = r'C:\Users\ys\Desktop\mu_lu'
# print "nc_files?????????",nc_files
# print "files[0:40]??????????", files[0:40]
# print "files[0:80:2]????????????", files[0:80:2]

try:
    inteval = '06'
    files = nc_files[0:40]
    print 'files', files
    wdd = []
    wff = []
    ww = []
    cn2 = []
    height = []
    timeinfo = []
    for file in files:
        print file
        data = windprofiler.read_profiler_sdz(file)

        # print 'read file ',file    #可以
        height.append(data['height'][0:30])
        # print 'height::',height   #有数据
        #print (data['height'])
        wdd.append(data['wdd'][0:30])
        # print 'wdd::',wdd   #有数据
        wff.append(data['wff'][0:30])
        print 'wff::', wff
        ww.append(data['ww'][0:30])
        cn2.append(data['cn2'][0:30])
        timeinfo.append(data['timeinfo'])
    # 转化为数组，并对初始值进行处理

    wdd = np.array(wdd)
    # print 'wdd:::',wdd  #没问题
    wff = np.array(wff)
    # print 'wff::',wff
    ww = -np.array(ww)
    cn2 = np.array(cn2)
    height = np.array(height)

    wdd[np.where(np.abs(wdd) > 360.0)] = np.nan
    wff[np.where(np.abs(wff) > 100.)] = np.nan
    ww[np.where(np.abs(ww) > 100.)] = np.nan
    cn2[np.where(np.abs(cn2) > 1000.)] = np.nan
    pressure = windprofiler.height2pressure(height)
    moment = windprofiler.moment(wff, ww)

    wff[np.where(wff < 1.0)] = 1.0
    uu = -wff * np.sin(np.deg2rad(wdd))
    vv = -wff * np.cos(np.deg2rad(wdd))

    size = wdd.shape
    print 'size:', size
    x = np.linspace(1, size[0], size[0])
    y = np.linspace(1, size[1], size[1])
    xx, yy = np.meshgrid(x, y)
    xx = np.transpose(xx)
    yy = np.transpose(yy)
    print "uu:::>>>>>>>>>>>>>>>", uu
    name = (os.path.basename(files[0]))[6:16] + '_' + str(inteval).zfill(2)
    # print wff
    r = draw_windbarb(xx, yy, uu, vv, wff, savepic=outdir + '\\' + name + 'windbarb.png')
    png2gif(outdir + '\\' + name + 'windbarb.png', outdir + '\\' + name + 'windbarb.gif')

except:
    pass

try:
    inteval = '12'
    files = nc_files[0:80:2]
    wdd = []
    wff = []
    ww = []
    cn2 = []
    height = []
    timeinfo = []
    for file in files:
        data = windprofiler.read_profiler_sdz(file)
        # print 'read file ',file
        height.append(data['height'][0:30])
        #print (data['height'])
        wdd.append(data['wdd'][0:30])
        wff.append(data['wff'][0:30])
        ww.append(data['ww'][0:30])
        cn2.append(data['cn2'][0:30])
        timeinfo.append(data['timeinfo'])
    # 转化为数组，并对初始值进行处理

    wdd = np.array(wdd)
    wff = np.array(wff)
    ww = -np.array(ww)
    cn2 = np.array(cn2)
    height = np.array(height)

    wdd[np.where(np.abs(wdd) > 360.0)] = np.nan
    wff[np.where(np.abs(wff) > 360.0)] = np.nan  # 修改100为360
    ww[np.where(np.abs(ww) > 100.)] = np.nan
    cn2[np.where(np.abs(cn2) > 1000.)] = np.nan
    pressure = windprofiler.height2pressure(height)
    moment = windprofiler.moment(wff, ww)

    wff[np.where(wff < 1.0)] = 1.0
    uu = -wff * np.sin(np.deg2rad(wdd))
    vv = -wff * np.cos(np.deg2rad(wdd))

    size = wdd.shape
    print 'size,', size
    x = np.linspace(1, size[0], size[0])
    y = np.linspace(1, size[1], size[1])
    xx, yy = np.meshgrid(x, y)
    xx = np.transpose(xx)
    yy = np.transpose(yy)
    print "uu>>>>>>>>>>>>>>>>", uu
    name = (os.path.basename(files[0]))[6:16] + '_' + str(inteval).zfill(2)
    # print wff
    r = draw_windbarb(xx, yy, uu, vv, wff, savepic=outdir + '\\' + name + 'windbarb.png')
    png2gif(outdir + '\\' + name + 'windbarb.png', outdir + '\\' + name + 'windbarb.gif')

except:
    pass

try:
    inteval = '30'
    files = nc_files[0:200:5]
    wdd = []
    wff = []
    ww = []
    cn2 = []
    height = []
    timeinfo = []
    for file in files:
        data = windprofiler.read_profiler_sdz(file)
        # print 'read file ',file
        height.append(data['height'][0:30])
        #print (data['height'])
        wdd.append(data['wdd'][0:30])
        wff.append(data['wff'][0:30])
        ww.append(data['ww'][0:30])
        cn2.append(data['cn2'][0:30])
        timeinfo.append(data['timeinfo'])
    # 转化为数组，并对初始值进行处理

    wdd = np.array(wdd)
    wff = np.array(wff)
    ww = -np.array(ww)
    cn2 = np.array(cn2)
    height = np.array(height)

    wdd[np.where(np.abs(wdd) > 360.0)] = np.nan
    wff[np.where(np.abs(wff) > 360.0)] = np.nan  # 修改100为360
    ww[np.where(np.abs(ww) > 100.)] = np.nan
    cn2[np.where(np.abs(cn2) > 1000.)] = np.nan
    pressure = windprofiler.height2pressure(height)
    moment = windprofiler.moment(wff, ww)

    wff[np.where(wff < 1.0)] = 1.0
    uu = -wff * np.sin(np.deg2rad(wdd))
    vv = -wff * np.cos(np.deg2rad(wdd))

    size = wdd.shape
    print 'size>>>>>>>>>>', size
    x = np.linspace(1, size[0], size[0])
    y = np.linspace(1, size[1], size[1])
    xx, yy = np.meshgrid(x, y)
    xx = np.transpose(xx)
    yy = np.transpose(yy)
    print "uu>>>>>>>>", uu
    name = (os.path.basename(files[0]))[6:16] + '_' + str(inteval).zfill(2)
    # print wff
    r = draw_windbarb(xx, yy, uu, vv, wff, savepic=outdir + '\\' + name + 'windbarb.png')
    png2gif(outdir + '\\' + name + 'windbarb.png', outdir + '\\' + name + 'windbarb.gif')

except:
    pass
