#! /usr/bin/env python
#coding=utf-8
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from windprofiler import windprofiler
import glob
from matplotlib import mpl
from pylab import *
import datetime
from match_time_aws_profiler import *
from scipy import ndimage
#from interp_2d import wgr_congrid
from profile_index  import wind_shear,jet_index,draw_index
import ConfigParser,os,sys,string
config=ConfigParser.ConfigParser()
from png2gif import png2gif
import pyemf
import matplotlib





def draw_windbarb(xx,yy,uu,vv,wff,savepic='1.png'):
    # start with a rectangular Figure
    fig1 = plt.figure(figsize=(12,8))
    #print 'there is in draw_windbarb'
    axScatter = plt.axes(rect_scatter)
    windprofiler.windbarb2(axScatter,xx,yy,uu,vv,wff,sid='hd')
    size = uu.shape
    #print 'the shape of uu is',size,[0,size[0],0,size[1]+1]
    axScatter.axis([0,size[0],0,size[1]+1])
    
    myticks = range(10)
    myticks = [v*3 for v in myticks]
    mylabels =[]
    mylabels = [timeinfo[v][11:16] for v in myticks]
    plt.xticks(myticks,mylabels,rotation=0,size=12,weight='bold')
    axScatter.text(size[0],-1,'(h)',size=14,weight='bold')
    
    myticks = range(12)
    myticks = [v*3 for v in myticks]
    mylabels =[]
    #print 'height',(height[0][myticks]).tolist()
    mylabels = [str(int(v+46)) for v in (height[0][myticks]).tolist()]
    plt.yticks(myticks,mylabels,rotation=0,size=12,weight='bold')
    
    '''
    myticks = range(11)
    myticks = [v*3+1 for v in myticks]
    labels = [ str(int(v)) for v in (pressure[0][myticks]).tolist()]
    for ii in range(11):         
        axScatter.text(-2,myticks[ii],labels[ii],rotation=30,size=9,weight='bold',color='r')
    
    axScatter.text(-3,size[1]+1,'hPa',size=10,weight='bold',color='r')
    '''
    axScatter.text(-1,size[1]+1,'(m)',size=14,weight='bold')
    
    #------------------------------------------------
    '''
    axnotes = plt.axes(rect_notes)
    
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)
    
    axnotes.barbs(4, 1, 8, 0,length=5,fill_empty=False,barbcolor='#000000',\
             sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5,1,'0-8m/s',fontsize = 8,weight='bold')
    axnotes.barbs(4, 3, 12, 0,length=5,fill_empty=False,barbcolor='#0000FF',\
             sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5,3,'8-12m/s',fontsize = 8,weight='bold')
    
    axnotes.barbs(4, 5, 17, 0,length=5,fill_empty=False,barbcolor='#00FF00',\
             sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5,5,'12-17m/s',fontsize = 8,weight='bold')
    axnotes.barbs(4, 7, 25, 0,length=5,fill_empty=False,barbcolor='#FF0000',\
             sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5,7,'17-25m/s',fontsize = 8,weight='bold')        
    axnotes.barbs(4, 9, 30, 0,length=5,fill_empty=False,barbcolor='#9900FF',\
             sizes=dict(emptybarb=0.2,spacing=0.20),barb_increments=dict(half=2, full=4, flag=20))
    axnotes.text(5,9,'>25m/s',fontsize = 8,weight='bold')  
    
    axnotes.text(6,48,'HD(54399)',size=8,weight='bold',horizontalalignment='center')
    axnotes.text(6,45,'Sea level:46m',size=7,weight='bold',horizontalalignment='center')          
    axnotes.axis([0,14,0,50])
    '''
    #fig1.savefig(savepic,transparent=False,dpi=100)
    matplotlib.use('EMF')
    fig1.savefig("test-matplotlib2.emf",dpi=300)
    '''
    width=8.0
    height=6.0
    dpi=300
    
    emf=pyemf.EMF(width,height,dpi)
    #thin=emf.CreatePen(pyemf.PS_SOLID,1,(0x01,0x02,0x03))
    emf.SelectObject(fig1)
    #emf.Polyline([(0,0),(width*dpi,height*dpi)])
    #emf.Polyline([(0,height*dpi),(width*dpi,0)])
    emf.save("test-1.emf")
    '''
    #plt.show()
 
 

    
 

def draw_pcolor(x,y,ww,levels=[0,5],colors=colors,title='title',savepic ='savepic.png',cb_fmt = '%.2f',**kc):
    #---pic2-----
    #print levels
    smooth_kernel = 0.3
    #ww = ndimage.gaussian_filter(ww,[smooth_kernel,smooth_kernel])
    
    rcParams['xtick.labelsize'] = 9.0
    rcParams['ytick.labelsize'] = 9.0
    
    fig = plt.figure(figsize=(12,8))
    z = ww.copy()
    z=np.transpose(z)
    size = z.shape

    print 'this is in draw pcolor '
    #print 'the shape of z is',size
    axScatter = plt.axes(rect_scatter)
    #cs =imshow(z, interpolation='nearest',**kc)
    if len(colors)>0:
        cs = contourf(z,levels,colors=colors)
        #cs2=contour(z,levels,colors='k',linewidths=1.0)
        #plt.clabel(cs2, inline=True, fmt='%.1f', fontsize=10)
        #cs.cmap.set_under(colors[-1])
        #cs.cmap.set_over(colors[0])
        
    else:
        cs = contourf(z)
        #cs2=contour(z,colors='k',linewidths=1.0)
        #plt.clabel(cs2, inline=True, fmt='%.1f', fontsize=10)
        

    
    axScatter.axis([0,size[1],0,size[0]+1])
    
    myticks = range(14)
    myticks = [v*3 for v in myticks]
    mylabels =[]
    mylabels = [timeinfo[v][5:16] for v in myticks]
    plt.xticks(myticks,mylabels,rotation=30,size=9,weight='bold')
    
    myticks = range(12)
    myticks = [v*3 for v in myticks]
    mylabels =[]
    
    mylabels = [str(int(v+46)) for v in (height[0][myticks]).tolist()]
    plt.yticks(myticks,mylabels,rotation=0,size=8,weight='bold')
    '''
    myticks = range(11)
    myticks = [v*3+1 for v in myticks]
    labels = [ str(int(v)) for v in (pressure[0][myticks]).tolist()]
    for ii in range(11):         
        axScatter.text(-2,myticks[ii],labels[ii],rotation=30,size=9,weight='bold',color='r')
    
    axScatter.text(-3,size[0]+1,'hPa',size=10,weight='bold',color='r')
    '''
    axScatter.text(-1,size[0]+1,'m',size=10,weight='bold')
    
    
        #------------------------------------------------
    axnotes = plt.axes(rect_notes)
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)
    
    
    # no labels
    
    cax = plt.axes([0.88,0.3,0.03,0.4])
    
    plt.colorbar(cs,format=cb_fmt,cax=cax,extend="both")
    #title
    
    axnotes.text(1,25,title,verticalalignment='center',rotation=90)        
    axnotes.axis([0,14,0,50])
    #axnotes.text(6,48,'HD(54399)',size=8,weight='bold',horizontalalignment='center')
    fig.savefig(savepic,transparent=True,dpi=100)
  





current_path =  os.getcwd()#string.replace(os.path.dirname(__file__),'\\','/')
config.readfp(open(current_path+'/his_ini.cfg','r'))  
indir = config.get('hd','indir')        
outdir = config.get('hd','outdir')
#print 'xxxxxxxxxxxxxxx',outdir
year = config.get('hd','year')
month = config.get('hd','month')
day = config.get('hd','day')
hour = config.get('hd','hour')
minute = config.get('hd','minute')
inteval = config.get('hd','inteval')
tad_vmin = config.get('hd','tad_vmin')
tad_vmax = config.get('hd','tad_vmax')
ww_vmin = config.get('hd','ww_vmin')
ww_vmax = config.get('hd','ww_vmax')
is_auto_update = config.get('hd','is_auto_update')
print 'interval =',inteval
cbar = config.get('colorbar','colorbar_1')
barlist = cbar.split(',')
paleete = [v for v in barlist]


nullfmt   = NullFormatter()         # no labels
# definitions for the axes
left, width = 0.05, 0.8
bottom, height = 0.1, 0.88
bottom_h = bottom+height
left_h = left+width
rect_scatter = [left, bottom, width, height]
rect_notes = [left_h, bottom, 0.13, height]



#print 'indir = ',indir
# the scatter plot:
windprofiler = windprofiler()
#print year,month,day,hour,minute
filestime,startime,endtime = windprofiler.get_filename(year,month,day,hour,minute,interv=inteval,num=30)
#print filestime
#files = [indir+'\\'+'Z_RADA_I_54399_'+v+'_P_WPRD_LC_ROBS.TXT' for v in filestime]
files = []
for v in filestime:
    s = glob.glob(indir+'\\*'+v+'*')
    if len(s)>0:
        files.append(s[0])
    else:
        files.append(indir+'\\'+'Z_RADA_I_54399_'+v+'_P_WPRD_LC_ROBS.TXT')
#print 'the files is ',(files)

wdd = []
wff = []
ww = []
cn2 = []
height = []
timeinfo = []
for file in files:
    data = windprofiler.read_profiler_hd(file)
    #print 'read file ',file
    height.append(data['height'])
    wdd.append(data['wdd'])
    wff.append(data['wff'])
    ww.append(data['ww'])
    cn2.append(data['cn2'])
    timeinfo.append(data['timeinfo'])


#转化为数组，并对初始值进行处理

wdd = np.array(wdd)
wff = np.array(wff)
ww = np.array(ww)
cn2 = np.array(cn2)
height = np.array(height)
wdd[np.where(wdd == 99999.9)] = np.nan
wff[np.where(wff == 99999.9)] = np.nan
ww[np.where(ww == 99999.9)] = np.nan
cn2[np.where(cn2 == 99999.9)] = np.nan
pressure = windprofiler.height2pressure(height)
moment =  windprofiler.moment(wff,ww)    




wff[np.where(wff < 1.0)] = 1.0 
uu = -wff*np.sin(np.deg2rad(wdd))
vv = -wff*np.cos(np.deg2rad(wdd))

size = wdd.shape

x = np.linspace(1,size[0],size[0])
y = np.linspace(1,size[1],size[1])
xx,yy = np.meshgrid(x, y)
xx = np.transpose(xx)
yy = np.transpose(yy)

name = str(year)+str(month).zfill(2)+str(day).zfill(2)+str(hour).zfill(2)+'_'+str(inteval).zfill(2)

try:
    r= draw_windbarb(xx,yy,uu,vv,wff,savepic=outdir+'\\'+name+'windbarb.png')
    #png2gif(outdir+'\\'+name+'windbarb.png',outdir+'\\'+name+'windbarb.gif')
    '''
    width=8.0
    height=6.0
    dpi=300

    emf=pyemf.EMF(width,height,dpi)
    thin=emf.CreatePen(pyemf.PS_SOLID,1,(0x01,0x02,0x03))
    emf.SelectObject(thin)
    emf.Polyline([(0,0),(width*dpi,height*dpi)])
    emf.Polyline([(0,height*dpi),(width*dpi,0)])
    emf.save("test-1.emf")
    '''
except:    
    pass    



cmap = get_cmap('spectral')
cmap.set_over('#333333')
cmap.set_under('#660000')  
try:
    #--------ww----------------------
    #levels = np.linspace(np.nanmin(ww),np.nanmax(ww),24)
    levels = [-999.0,-1.0,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.1,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.5,2.0,2.5,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,999]
    colors = ['#8B1C62','#ff0000', '#ff3900', '#ff6a00', '#ff8400', '#ff9e00', '#ffb800', '#ffd200', '#ffed00', '#ffff18', '#d8e5ff', '#c3d6ff', '#aac6ff', '#90b4ff', '#76a3ff', '#5b91ff', '#4784ff', '#3376ff', '#1d68ff', '#075aff','#0000CD','#00008B','#000080','#191970','#006400','#008000','#008B00','#00CD00','#00EE00','#00FF00','#8B7500','#000000']
    r = draw_pcolor(xx,yy,ww,levels=levels,colors=colors,aspect='auto',vmin=-5,vmax=5,origin='lower',cmap=cmap,title='vertical velocity (m/s)',savepic =outdir+'\\'+name+'ww.png',cb_fmt = '%.1f')
    png2gif(outdir+'\\'+name+'ww.png',outdir+'\\'+name+'ww.gif')
except:
    s=sys.exc_info()
    print "Error '%s' happened on line %d" % (s[1],s[2].tb_lineno)
       
   
try:
    ########tad---------------------
    tad =windprofiler.temp_tad2(wff,wdd,pressure)
    mask =np.isinf(tad)
    tad[np.where(mask == True)]=np.nan
    tad =tad*1.e5
    levels = np.linspace(np.nanmin(tad),np.nanmax(tad),24)
    levels = [-999.0,-50.0,-40.0,-30.0,-25.0,-20.0,-15.0,-10.0,-8.0,-6.0,-4.0,-2.0,-1.0,1.0,2.0,4.0,6.0,8.0,10.0,15.0,20.0,25.0,30.0,40.0,50.0,999.0]
    colors = ['#2400d8', '#1d0fe8', '#1a24f8', '#2348fc', '#2d64ff', '#3a81ff', '#499bff', '#59b3ff', '#69c6ff', '#7dd8ff', '#93e6ff', '#a6efff', '#bbf8ff', '#fff1be', '#ffe2a8', '#ffd295', '#ffb880', '#ff9c6b', '#ff805b', '#ff5e4b', '#fe3c3c', '#f92e37', '#f12333', '#de1830', '#c30c29', '#a50021']
    r = draw_pcolor(xx,yy,tad,levels=levels,colors=colors,aspect='auto',vmin=-20,vmax=20,origin='lower',cmap=cmap,title='temp advection(x1.e5)',savepic =outdir+'\\'+name+'t_ad.png',cb_fmt = '%.1f')
    png2gif(outdir+'\\'+name+'t_ad.png',outdir+'\\'+name+'t_ad.gif')
except:
    pass   
try:
    #--------wff----------------------
    levels = [0.0,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,12.0,14.0,16.0,18.0,20.0,25.0,30.0,40.0,50.0,999.0]
    colors = ['#99ccff', '#8ebdff', '#5976ff', '#284eda', '#003fa7', '#00747b', '#008c38', '#0b9e0b', '#38b038', '#84ce43', '#ceec36', '#f9fd05', '#ffec00', '#ffd113', '#ffab47', '#fe822f', '#f75512', '#e62700', '#cd0e00', '#b20000', '#990000']
    r = draw_pcolor(xx,yy,wff,levels=levels,colors=colors,aspect='auto',vmin=-5,vmax=5,origin='lower',cmap=cmap,title='horizontal windspeed(m/s)',savepic =outdir+'\\'+name+'wff.png',cb_fmt = '%.1f')
    png2gif(outdir+'\\'+name+'wff.png',outdir+'\\'+name+'wff.gif')
except:
    s=sys.exc_info()
    print "Error '%s' happened on line %d" % (s[1],s[2].tb_lineno)




try:
    #-low lev jet
    low_lev_jet = windprofiler.low_lev_jet(wff,height)
    
    
    levels = np.linspace(np.nanmin(low_lev_jet),np.nanmax(low_lev_jet),24)
    r = draw_pcolor(xx,yy,low_lev_jet,levels=levels,aspect='auto',origin='lower',title='low level jet (m/s)',savepic =outdir+'\\'+name+'low_level_jet.png',cb_fmt = '%.1f')
    png2gif(outdir+'\\'+name+'low_level_jet.png',outdir+'\\'+name+'low_level_jet.gif')
except:
    pass    
try:
    #----cn2------------
    cn2=cn2*1.e15
    #cmap2=plt.get_cmap('Accent')
    #levels = np.linspace(np.nanmin(cn2),np.nanmax(cn2),24)
    levels = [-9999, 0.,   10.,   20.,   30.,   40.,   50.,   60.,   70.,   80.,90.,  100.,  110.,  120.,  130.,  140.,  150.,  160.,  170.,  180.,9999 ]
    colors = ['#99ccff', '#8ebdff', '#5976ff', '#284eda', '#003fa7', '#00747b', '#008c38', '#0b9e0b', '#38b038', '#84ce43', '#ceec36', '#f9fd05', '#ffec00', '#ffd113', '#ffab47', '#fe822f', '#f75512', '#e62700', '#cd0e00', '#b20000', '#990000']
    r = draw_pcolor(xx,yy,cn2,levels=levels,colors = colors,aspect='auto',vmin=-5,vmax=5,origin='lower',cmap=cmap,title='cn2(x1.e12)',savepic =outdir+'\\'+name+'cn2.png',cb_fmt = '%.1f')
    png2gif(outdir+'\\'+name+'cn2.png',outdir+'\\'+name+'cn2.gif')
except:
    pass    
try:
    #----moment------------
    
    #cmap2=plt.get_cmap('Accent')
    levels = np.linspace(np.nanmin(moment),np.nanmax(moment),24)
    r = draw_pcolor(xx,yy,moment,levels=levels,aspect='auto',origin='lower',cmap=cmap,title='moment',savepic =outdir+'\\'+name+'moment.png',cb_fmt = '%.1f')
    png2gif(outdir+'\\'+name+'moment.png',outdir+'\\'+name+'moment.gif')
except:
    pass 


#plt.show()
#-------------draw aws pic --------------------------------------------
try:
    
    aws_indir = config.get('aws5_54399','indir')        
    aws_outdir = config.get('aws5_54399','outdir')
    
    #start time 
    start_time = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
    end_time = start_time + datetime.timedelta(minutes = -int(inteval) * 40) #对应40个风（风扩线）
    aws_time_list = match_time_aws(start_time,end_time)
    aws_file_list = []
    
    for item in aws_time_list:
        ss = item.timetuple()
        st = str(ss[0])+str(ss[1]).zfill(2)+str(ss[2]).zfill(2)+str(ss[3]).zfill(2)+str(ss[4]).zfill(2)+'00'
        #aws_file_list.append(r'x:\aws'+'\\'+'BJAWS_'+st+'.TXT')
        aws_file_list.append(aws_indir+'\\'+'BJAWS_'+st+'.TXT')
        #print r'C:\mywork\code\idl\aws\aws_data\20091031-20091101aws'+'\\'+'BJAWS_'+st+'.TXT'
    #print 'aws_file_list',aws_file_list
    data = get_aws_timeserier(aws_file_list,id='54399')
    
    timeinfo = data['timeinfo']
    temp = data['temp']
    rh = data['rh']
    pres = data['pres']
    rain = data['rain']
    wff2 = data['wff2']
    wdd2 = data['wdd2']
    shunshi_wff = data['shunshi_wff']
    shunshi_wdd = data['shunshi_wdd']
    
    temp = np.array(temp)
    rh = np.array(rh)
    pres = np.array(pres)
    rain = np.array(rain)
    wff2 = np.array(wff2)
    wdd2 = np.array(wdd2)
    
    temp[np.where(temp == 99999.0)] = np.nan
    rh[np.where(rh == 99999.0)] = np.nan
    pres[np.where(pres == 99999.0)] = np.nan
    rain[np.where(rain ==99999.0)] = np.nan
    wff2[np.where(wff2 ==99999.0)] = np.nan
    wdd2[np.where(wdd2 ==99999.0)] = np.nan
    wff2[np.where(wff2 < 1.0)] = 1.0
    uu2 = -wff2*np.sin(np.deg2rad(wdd2))
    vv2 = -wff2*np.cos(np.deg2rad(wdd2))
    

    
    #r=draw_aws_element(temp,rh,pres,rain,uu2,vv2,timeinfo,outpic=aws_outdir+'\\'+name+'aws.png')
    r=draw_station_series(temp,rh,pres,rain,uu2,vv2,timeinfo,outpic=aws_outdir+'\\'+name+'aws.png')
    png2gif(aws_outdir+'\\'+name+'aws.png',aws_outdir+'\\'+name+'aws.gif')
except:
       
    s=sys.exc_info()
    print "Error '%s' happened on line %d" % (s[1],s[2].tb_lineno)
       
    
#------------------------
'''
try:
    #-------draw radar mosaic----------------
    config.readfp(open(current_path+'/his_ini.cfg','r'))  
    mosaic_indir = config.get('mosaic_hd','indir')        
    mosaic_outdir = config.get('mosaic_hd','outdir')
    start_time = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute)) 
    start_time = start_time + datetime.timedelta(hours = -8)
    end_time = start_time + datetime.timedelta(minutes = -int(inteval) * 40)
    
    mosaic_time_list = match_time_mosaic(start_time,end_time)
    print 'mosaic_time_list=',mosaic_time_list
    
    mosaic_file_list = []
    timeinfo= []
    for item in mosaic_time_list:
        ss = item.timetuple()
        st = str(ss[0])[2:4]+str(ss[1]).zfill(2)+str(ss[2]).zfill(2)+str(ss[3]).zfill(2)+str(ss[4]).zfill(2)
        #aws_file_list.append(r'x:\aws'+'\\'+'BJAWS_'+st+'.TXT')
        mosaic_file_list.append(mosaic_indir+'\\'+st+'.nc')
        timeinfo.append(st)
    #print 'mosaic files = ',mosaic_file_list
    
    data = read_radar_mosaic_point(mosaic_file_list,station = '54399')
    
    
    ##y lim -0.54 5
    dbz= data[0:6]
    #print 'truncted dbz shape',dbz.shape 
    cmap_mosaic = mpl.colors.ListedColormap(['#00FFFF','#0099FF','#0033FF','#000099',\
                                         '#00FF00','#00CC66','#009933','#FFFF00',\
                                        '#FFCC33','#FF6633','#FF0066','#FF00FF',\
                                         '#9966FF','#990099','#6633FF'])
    
    #cmap_mosaic.set_over('#FF0000')
    #cmap_mosaic.set_under('#999999') 
    print 'dbz data is ',dbz.shape
    #dbz = wgr_congrid(dbz,[20,(dbz.shape)[1]])
    try:
        draw_point_dbz_seriers(dbz,timeinfo,aspect='auto',origin='lower',cmap = cmap_mosaic,vmin=5,vmax=75,title='radar echo at (54399) dBz',outpic = mosaic_outdir+'\\'+name+'mosaic.png')
    except:
        pass
except:
    pass    
'''

#======调用profile_index 计算其他相关指数=============
try:
    wshear = wind_shear(wff,wdd,height)
    #print  'low_shear=',wshear
    
    (II_12,II_20) = jet_index(wff,wdd,height)
    #print 'low level jet index = ',II_12
    II_12[np.isnan(II_12)] = 0.0
    wshear[np.isnan(wshear)] = 0.0
    II_20[np.isnan(II_20)] = 0.0
    result = draw_index(wshear,outpic=outdir+'\\'+name+'wshear.png',anno=['wind shear','(m/s.km)'])
    png2gif(outdir+'\\'+name+'wshear.png',outdir+'\\'+name+'wshear.gif')
    result = draw_index(II_12,outpic=outdir+'\\'+name+'II_12.png',anno=['lower jet index','(m/s.km)'])
    png2gif(outdir+'\\'+name+'II_12.png',outdir+'\\'+name+'II_12.gif')
    result = draw_index(II_20,outpic=outdir+'\\'+name+'II_20.png',anno=['lower jet index','(m/s.km)'])
    png2gif(outdir+'\\'+name+'II_20.png',outdir+'\\'+name+'II_20.gif')    
    #result = draw_index(II_20,outpic=outdir+'\\'+name+'II_20.png',anno=['higher jet index','(m/s.km)'])
except:
    pass    


#--------------12
