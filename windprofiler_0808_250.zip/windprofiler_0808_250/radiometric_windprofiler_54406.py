#! /usr/bin/env python
#coding=utf-8

'''
解析微波辐射计数据，并绘制图形，提供给信息中心LDAD显示


站名	站号	经度(度分)	纬度(度分)	海拔高度（米）	运行时间	是否仍在业务运行
观象台	54511	E116°28′00″	N39°48′00″	31.3	2005-8-18至今	是
车道沟	A1024	E116°17′24″	N39°56′42″	75	2007年至2011-5-13	否
延庆	54406	E115°58′08″	N40°26′58″	489.4	2011-5-13至今	是
顺义	54398	E116°37′00″	N40°08′00″	28.6	2008年7月29至2011-9-23	否
上甸子	54421	E117°07′00″ 	N40°39′00″	293.3	2011-9-29至今	是


目前北京市气象局在延庆、观象台和上甸子各放置一台地基微波辐射计。
其中延庆和观象台的地基微波辐射计为12通道（TP WVP-3000型），
分别是22.235GHz、23.035GHz、23.835GHz、26.235GHz、30.000 GHz、
51.250 GHz、52.280 GHz、53.850 GHz、54.940 GHz、56.660 GHz、
57.290 GHz、58.800 GHz。该12通道的地基微波辐射计所反演得到的大气廓线共47层，
高度分别为：0.00、0.10、0.20、0.30、0.40、0.50、0.60、0.70、0.80、0.90、1.00、
1.25、1.50、1.75、2.00、2.25、2.50、2.75、3.00、3.25、3.50、3.75、4.00、4.25、
4.50、4.75、5.00、5.25、5.50、5.75、6.00、6.25、6.50、6.75、7.00、7.25、7.50、
7.75、8.00、8.25、8.50、8.75、9.00、9.25、9.50、9.75、10.00Km。

放置于上甸子的地基微波辐射计为35通道（MP-3000A型）。分别是22.000 GHz、
22.234 GHz、22.500 GHz、23.000 GHz、23.034 GHz、23.500 GHz、23.834 GHz、
24.000 GHz、24.500 GHz、25.000 GHz、26.000 GHz、26.234 GHz、26.500 GHz、
27.000 GHz、27.500 GHz、28.000 GHz、28.500 GHz、29.000 GHz、29.500 GHz、
30.000 GHz、51.248 GHz、51.760 GHz、52.280 GHz、52.804 GHz、53.336 GHz、
53.848 GHz、54.400 GHz、54.940 GHz、55.500 GHz、56.020 GHz、56.660 GHz、
57.288 GHz、57.964 GHz、58.800GHz。该35通道的地基微波辐射计所反演的导的
大气廓线共58层，高度分别为：0.00、0.05、0.10、0.15、0.20、0.25、0.30、0.35、
0.40、0.45、0.50、0.60、0.70、0.80、0.90、1.00、1.10、1.20、1.30、1.40、
1.50、1.60、1.70、1.80、1.90、2.00、2.25、2.50、2.75、3.00、3.25、3.50、
3.75、4.00、4.25、4.50、4.75、5.00、5.25、5.50、5.75、6.00、6.25、6.50、
6.75、7.00、7.25、7.50、7.75、8.00、8.25、8.50、8.75、9.00、9.25、9.50、
9.75、10.00Km




数据结构：

12通道(生成4种文件)：
yyyy-MM-dd_hh-mm-ss_lv0.csv
yyyy-MM-dd_hh-mm-ss_lv1.csv
yyyy-MM-dd_hh-mm-ss_lv2.csv
yyyy-MM-dd_hh-mm-ss_tip.csv

35通道(生成5种文件)：
yyyy-MM-dd_hh-mm-ss_lv0.csv
yyyy-MM-dd_hh-mm-ss_lv1.csv
yyyy-MM-dd_hh-mm-ss_lv2.csv
yyyy-MM-dd_hh-mm-ss_tip.csv
yyyy-MM-dd_hh-mm-ss_ser.txt

其中：yyyy为年；MM为月；dd为日；hh为小时；mm为分钟；ss为秒
lv0表示0级文件；lv1表示1级文件；lv2表示2级文件；tip表示标定文件；ser表示串行通讯端口日志文件。

数据实体的内容描述：
测量从地面到高空10公里的温度、水汽、相对湿度以及液态水的垂直廓线。另外，
地面的气象传感器测量气温、相对湿度、大气压以及是否降水。

下面只给出绘图需要的level2文件的格式
level2文件包括实时的温度、水汽、相对湿度和液态水廓线。通过level1数据和神经网络
文件反演得到。Level2文件包含以下类型：
10：level2的文件头
11：温度廓线
12：水汽密度廓线
13：相对湿度廓线
14：液态水廓线

#------------------------------------------------------------------------------
程序说明：

　：　读取外部配置文件，获取绘图时间范围，资料路径等信息
read_dataset :   读取微波辐射计数据，支持12通道和35通道两类数据
build_dataset:   利用读取出来的数据，根据配置信息构建绘图所需的数据块
draw_pic     :   绘制微波辐射计数据图片，支持24小时间隔
draw_pic6h   :   绘制微波辐射计数据图片，支持6小时间隔
height2pressure : 把高度转换为气压
rh2tdew      :   相对湿度转化为露点
程序编写： 王国荣 2013.08.08

'''

import ConfigParser,os,sys,string,csv,datetime,pdb
import numpy as np
from matplotlib.ticker import NullFormatter
from scipy import ndimage
from scipy import interpolate
from pylab import *
from skewt import SkewT

import matplotlib.font_manager as Font_manager
config=ConfigParser.ConfigParser()



class radiometric():
    def __init__(self):
        self.rootdir = ''
        self.time2draw = 24      #指定需要绘制的图形的时间范围
        
    def read_config(self,id = '54406'):
        
        #---------读取配置文件，获取启动程序所需的所用初始化信息---------
        current_path =  os.getcwd()  
        
        config.readfp(open(current_path+ os.sep +'ini.cfg','r'))
        self.rootdir  = config.get('radiometric_'+id,'rootdir')
        print 'rootdir=',self.rootdir
        self.elevation = config.get('radiometric_'+id,'elevation')
        
    def request_time(self,from_time='201404150000',to_time='201404161000'):
        '''根据用户提供的时间信息，判断需要读取的文件以及需要截取的内容长度'''
        print '*'*50
        print 'this is in request_time'
        print 'input: from_time = ',from_time,' to_time = ',to_time
        f_year=from_time[0:4]
        f_month = from_time[4:6]
        f_day = from_time[6:8]
        f_hour = from_time[8:10]
        f_minute = from_time[10:12]
        print 'f_year=%sf_month=%sf_day=%sf_hour=%sf_minute=%s'%(f_year,f_month,f_day,f_hour,f_minute)
        t_year=to_time[0:4]
        t_month = to_time[4:6]
        t_day = to_time[6:8]
        t_hour = to_time[8:10]
        t_minute = to_time[10:12]
        #print 't_year=%st_month=%st_day=%st_hour=%s'%(t_year,t_month,t_day,t_hour)
        date1 = datetime.datetime(int(f_year),int(f_month),int(f_day),int(f_hour),int(f_minute))
        date2 = datetime.datetime(int(t_year),int(t_month),int(t_day),int(t_hour),int(t_minute))
        print date1,date2
        
        #返回需要读取的文件时间
        time_list = []
        days = int(t_day) - int(f_day)
        seconds = int(t_minute) - int(f_minute)
        print 'days =',days,' seconds=',seconds
        if days < 0:
            days = 1
        len_t = days +1
        if seconds != 0 :
            days += 1
        for i in range(len_t):
            n_date = date1+datetime.timedelta(days=i)
            #print n_date
            time_list.append(n_date)
            
        start_points = date1.hour*60+date1.minute  #起始时间距离00:00分的时间点数
        end_points = 1440 - (date2.hour*60+date2.minute)  #结束时间距离24:00(00:00)的时间点数  
        print 'the return result is '
        print 'start_points = ',start_points,' end_points = ',end_points,'time_list=',time_list
        
        return time_list,start_points,end_points
    
        
    def read_dataset(self,file):
        '''
        读取微波辐射计数据
        '''
        print '*'*50
        
        tamb=[]
        press=[]
        rh=[]
        tir=[]#云底温度
        rain=[] 
        vint = []
        lqint = []
        temp_2d = []
        rh_2d = []
        wv_2d = []
        lq_2d = []
        s_dates = []      
        
        self.read_config(id = '54511')  
        if 1:
            
            reader = csv.reader(open(file,'rb'))    
            tamb=[]
            press=[]
            rh=[]
            tir=[]#云底温度
            rain=[] 
            vint = []
            s_dates = []
            temp_2d = []
            rh_2d = []
            wv_2d = []
            lq_2d = []
            vint = []
            lqint = []
            cloud_base = []
            
            for line in reader:       
                if line[0] == 'Record':
                    height =  [np.float(v)+np.float(self.elevation)*0.001 for v in line[10:]]
                    
                if line[0] != 'Record':
                    #print line
                    
                    
                    #11：温度廓线
                    #12：水汽密度廓线
                    #13：相对湿度廓线
                    #14：液态水廓线
                    ##Vint:大气总水汽量（cm），Lint:大气总液态水图（mm）
                    data = [np.float(v) for v in line[10:]]
                    n_level = len(data)
                    if line[2].strip() == '11':
                        #地面气温，相对湿度，气压，云底亮温
                        tamb.append(float(line[3])) 
                        rh.append(float(line[4])) 
                        press.append(float(line[5])) 
                        tir.append(float(line[6]))
                        rain.append(line[7])
                        vint.append(float(line[8]))
                        lqint.append(float(line[9]))
                        
                        temp_2d.append(data)
                        string_time = line[1]        
                        t1= [2000+int(string_time[6:8]),int(string_time[0:2]),int(string_time[3:5]),\
                            int(string_time[9:11]),int(string_time[12:14]),int(string_time[15:17])]                                    
                        t2=datetime.datetime(t1[0],t1[1],t1[2],t1[3],t1[4],t1[5]) 
                        s_dates.append(t2)
                        
                    if line[2].strip() == '12':
                        wv_2d.append(data)
                    if line[2].strip() == '13':
                        rh_2d.append(data)
                    if line[2].strip() == '14':
                        lq_2d.append(data)
                    
                    
                    
            date1 = s_dates[0]#开始时间
            date2 = s_dates[-1]#datetime.datetime( 2000, 3, 6)
            start_points = date1.hour*60+date1.minute-1
            if start_points <0:
                start_points = 0
            end_points = 24*60 -date2.hour*60-date2.minute
                        
            print 'start points = ',start_points,date1
            print 'end points = ',end_points,date2
            
            
            
            
            #pdb.set_trace()
            
            #补充数据文件前后有几个分钟的数据不足的问题，
            #但是考虑到绘图时的效果，以及实际应用的中的一些问题，可以做以下优化：
            #（1）假如start_points <=5,表示前面只有不到5分钟的数据缺失，这种情况下
            #    我们可以认为对分析结果不会产生明显的影响，因此，可以用第一个有效数据来填充
            # （2） 对于end_points <=5,用最后一个有效数据来填充
            b=[99999.0]*n_level
            if start_points<=5:
                for i in range(start_points):
                    temp_2d.insert(0,temp_2d[0])
                    rh_2d.insert(0,rh_2d[0])
                    wv_2d.insert(0,wv_2d[0])
                    lq_2d.insert(0,lq_2d[0])
                    tamb.insert(0,tamb[0])
                    rh.insert(0,rh[0])
                    press.insert(0,press[0])
                    tir.insert(0,tir[0])
                    vint.insert(0,vint[0])
                    lqint.insert(0,lqint[0])
                    rain.insert(0,rain[0])
                    s_dates.insert(0,s_dates[0])
            else:
                for i in range(start_points):
                    temp_2d.insert(0,b)
                    rh_2d.insert(0,b)
                    wv_2d.insert(0,b)
                    lq_2d.insert(0,b)
                    tamb.insert(0,99999.0)
                    rh.insert(0,99999.0)
                    press.insert(0,99999.0)
                    tir.insert(0,99999.0)
                    vint.insert(0,99999.0)
                    lqint.insert(0,99999.0)
                    rain.insert(0,99999.0)
                    s_dates.insert(0,99999.0)
                
                

            if end_points <=5:
                for i in range(end_points):
                    temp_2d.append(temp_2d[-1])
                    rh_2d.append(rh_2d[-1])
                    wv_2d.append(wv_2d[-1])
                    lq_2d.append(lq_2d[-1])
                    tamb.append(tamb[-1])
                    rh.append(rh[-1])
                    press.append(press[-1])
                    tir.append(tir[-1])
                    vint.append(vint[-1])
                    lqint.append(lqint[-1])
                    rain.append(rain[-1])  
                    s_dates.append(s_dates[-1])
            else:
                for i in range(end_points):
                    temp_2d.append(b)
                    rh_2d.append(b)
                    wv_2d.append(b)
                    lq_2d.append(b)
                    tamb.append(99999.0)
                    rh.append(99999.0)
                    press.append(99999.0)
                    tir.append(99999.0)
                    vint.append(99999.0)
                    lqint.append(99999.0)
                    rain.append(99999.0)  
                    s_dates.append(99999.0)
            
       
        print '&&&&&&&&&&&&&&len(rh)',len(rh),np.asarray(rh_2d).shape
        result = {'temp_2d':temp_2d,'rh_2d':rh_2d,'wv_2d':wv_2d,'s_dates':s_dates,'height':height,\
                        'lq_2d':lq_2d,'tamb':tamb,'rh':rh,'press':press,'tir':tir,'lqint':lqint,'vint':vint,'rain':rain}
        
        return result

            
    def merge_data(self,from_time='201404150000',to_time='201404161000',outdir=''):
        '''根据时间信息，把一个或多个文件的内容连接起来
        '''
        print '*'*50
        print 'this is in merge_data'
        print 'input: from_time = ',from_time,' to_time = ',to_time
        temp_2d = []
        rh_2d = []
        wv_2d = []
        lq_2d = []
        tamb = []
        rh = []
        press = []
        tir = []
        vint = []
        lqint = []
        rain = []
        s_dates = []
        (time_list,start_points,end_points)=self.request_time(from_time,to_time)
        print 'after request_time'
        print 'return time_list is ',time_list
        #print 'back from request_time function'
        #print 'time_list=',time_list,'start_points=',start_points,'end_points=',end_points
        #这里的startpoints,end_points是全局的
        for i_time in time_list:
            print 'this time is ',i_time
            s= i_time.timetuple()
            
            file = self.rootdir + os.sep +str(s[0])+'-'+ \
                    str(s[1]).zfill(2)+'-'+str(s[2]).zfill(2)+'_00-01-00_lv2.csv'
            
                
            
            print 'the readed file :',file
            data = self.read_dataset(file)
            print 'after read cvs file'
            print 'len of rh list ' ,len(data['rh'])
            temp_2d.extend(data['temp_2d'])
            rh_2d.extend(data['rh_2d'])
            wv_2d.extend(data['wv_2d'])
            lq_2d.extend(data['lq_2d'])
            tamb.extend(data['tamb'])
            rh.extend(data['rh'])
            press.extend(data['press'])
            tir.extend(data['tir'])
            vint.extend(data['vint'])
            lqint.extend(data['lqint'])
            rain.extend(data['rain'])
            s_dates.extend(data['s_dates'])
            height = data['height']
    
        
        print 'after merger the data'
        
        ###把微波辐射计的数据插值成风廓线场的数据即可，时间轴不用插值，只有高度上插值
        xtime = len(s_dates[start_points:-end_points])
        print xtime
        ynew = np.asarray([0.15,0.27,0.39,0.51,0.63,0.75,0.87,0.99,1.11,1.23,1.35,1.47,1.59,1.71,1.83,1.95,\
                2.19,2.43,2.67,2.91,3.15,3.39,3.63,3.87,4.11,4.35,4.59,4.83,5.07,5.31,5.55,5.79,\
                6.03,6.27,6.51,6.75,6.99,7.23,7.47,7.71,7.95,8.19,8.43,8.67,8.91,9.15,9.39,9.63,9.87])  ##风廓线的height数组
        height_nan =[10.11,10.35,10.59,10.83,11.07,11.31,11.55,11.79,12.03]
        n_height =len(height_nan)
        b=[99999.0]*n_height
        ztemp_new =[]
        for i in range(xtime):
            #xtime = np.arange(100)
            yheight = np.asarray(height)
            print yheight.shape
            
            ztemp = np.asarray(temp_2d[start_points:-end_points][i])
            print ztemp.shape
            ztemp = np.transpose(ztemp)
            print ztemp.shape
            print '00000000000000000000000000000000000'
            #pdb.set_trace()
            
            newfunc =interpolate.interp1d(yheight,ztemp,kind='linear')            
            
            ztemp_n = newfunc(ynew)
            print ztemp_n.shape
            ztemp_new.extend(list(ztemp_n))
            ztemp_new.extend(b)
        
        '''
        height_nan =[10.11,10.35,10.59,10.83,11.07,11.31,11.55,11.79,12.03]
        print 'ynew==',ynew
        print 'list(ynew)==',list(ynew)
        ynew=list(ynew)
        ynew.extend(height_nan)
        print len(ynew)
        n_height=len(height)
        print 'n_height==',n_height
        b=[99999.0]*n_height
        '''
        ztemp_new =np.asarray(ztemp_new)
        print ztemp_new.shape
        yy_new = len(ynew)+len(b)
        ztemp_new =ztemp_new.reshape(xtime,yy_new)
        print ztemp_new.shape
        
       
        zrh_new =[]
        for i in range(xtime):
            #xtime = np.arange(100)
            yheight = np.asarray(height)
                        
            zrh = np.asarray(rh_2d[start_points:-end_points][i])
            print zrh.shape
            zrh = np.transpose(zrh)
            print zrh.shape
            print '00000000000000000000000000000000000'
            #pdb.set_trace()
            
            newfunc =interpolate.interp1d(yheight,zrh,kind='linear')            
            
            zrh_n = newfunc(ynew)
            print zrh_n.shape
            zrh_new.extend(list(zrh_n))
            zrh_new.extend(b)
        
        zrh_new =np.asarray(zrh_new)
        yy_new = len(ynew)+len(b)
        zrh_new =zrh_new.reshape(xtime,yy_new)
        print zrh_new.shape
        ynew = list(ynew)+height_nan
        
        return {'temp_2d':temp_2d[start_points:-end_points],'rh_2d':rh_2d[start_points:-end_points],'wv_2d':wv_2d[start_points:-end_points],\
                'lq_2d':lq_2d[start_points:-end_points],'tamb':tamb[start_points:-end_points],'rh':rh[start_points:-end_points],\
                'press':press[start_points:-end_points],'tir':tir[start_points:-end_points],'lqint':lqint[start_points:-end_points],\
                'vint':vint[start_points:-end_points],'rain':rain[start_points:-end_points],'s_dates':s_dates[start_points:-end_points],\
                'height':height,'ztemp_new':ztemp_new,'zrh_new':zrh_new,'ynew':ynew}
    
    def inter_dataset(self,from_time='201404150000',to_time='201404161000',outdir=''):
        print '*'*50
        print 'this is interploted_data'
        print 'input: from_time = ',from_time,' to_time = ',to_time
        temp_2d = []
        rh_2d = []
        wv_2d = []
        lq_2d = []
        tamb = []
        rh = []
        press = []
        tir = []
        vint = []
        lqint = []
        rain = []
        s_dates = []
        (time_list,start_points,end_points)=self.request_time(from_time,to_time)
        print 'after request_time'
        print 'return time_list is ',time_list
        #print 'back from request_time function'
        #print 'time_list=',time_list,'start_points=',start_points,'end_points=',end_points
        #这里的startpoints,end_points是全局的
        for i_time in time_list:
            print 'this time is ',i_time
            s= i_time.timetuple()
            
            file = self.rootdir + os.sep +str(s[0])+'-'+ \
                    str(s[1]).zfill(2)+'-'+str(s[2]).zfill(2)+'_00-01-00_lv2.csv'
            
                
            
            print 'the readed file :',file
            data = self.read_dataset(file)
            print 'after read cvs file'
            print 'len of rh list ' ,len(data['rh'])
            temp_2d.extend(data['temp_2d'])
            rh_2d.extend(data['rh_2d'])
            wv_2d.extend(data['wv_2d'])
            lq_2d.extend(data['lq_2d'])
            tamb.extend(data['tamb'])
            rh.extend(data['rh'])
            press.extend(data['press'])
            tir.extend(data['tir'])
            vint.extend(data['vint'])
            lqint.extend(data['lqint'])
            rain.extend(data['rain'])
            s_dates.extend(data['s_dates'])
            height = data['height']
        
        
        print 'after merger the data'
        
        
        ###把微波辐射计的数据插值成风廓线场的数据即可，时间轴不用插值，只有高度上插值
        xtime = np.asarray(s_dates[start_points:-end_points])
        yheight = np.asarray(height)
        ztemp = np.asarray(temp_2d[start_points:-end_points])
        #pdb.set_trace()
        newfunc =interpolate.interp2d(xtime,yheight,ztemp,kind='linear')
        
        xnew = xtime
        ynew = np.asarray([0.15,0.27,0.39,0.51,0.63,0.75,0.87,0.99,1.11,1.23,1.35,1.47,1.59,1.71,1.83,1.95,\
                2.19,2.43,2.67,2.91,3.15,3.39,3.63,3.87,4.11,4.35,4.59,4.83,5.07,5.31,5.55,5.79,\
                6.03,6.27,6.51,6.75,6.99,7.23,7.47,7.71,7.95,8.19,8.43,8.67,8.91,9.15,9.39,9.63,
                9.87,10.11,10.35,10.59,10.83,11.07,11.31,11.55,11.79,12.03])  ##风廓线的height数组
        ztemp_new = newfunc(xnew,ynew)
        
        
        
        return {'temp_2d':temp_2d[start_points:-end_points],'rh_2d':rh_2d[start_points:-end_points],'wv_2d':wv_2d[start_points:-end_points],\
                'lq_2d':lq_2d[start_points:-end_points],'tamb':tamb[start_points:-end_points],'rh':rh[start_points:-end_points],\
                'press':press[start_points:-end_points],'tir':tir[start_points:-end_points],'lqint':lqint[start_points:-end_points],\
                'vint':vint[start_points:-end_points],'rain':rain[start_points:-end_points],'s_dates':s_dates[start_points:-end_points],\
                'height':height,'ztemp_new':ztemp_new}
        

    

    def draw_pic(self,data,mainscale = [0.1, 0.1, 0.8, 0.8],colorbarscale=[0.91, 0.1, 0.02, 0.8],outdir = '',outname=''):
        nullfmt   = NullFormatter()
        rcParams['axes.labelsize'] = 18.0
        rcParams['xtick.labelsize'] = 9.0
        rcParams['ytick.labelsize'] = 9.0
        
        zhfont_bold = Font_manager.FontProperties(fname='D:\operation\smear-master\smear\simsun-bold.ttf')
        zhfont = Font_manager.FontProperties(fname='D:\operation\smear-master\smear\simsun.ttc')
        #----------------------------------------------------------------------
        left, width = 0.05, 0.8
        bottom, height = 0.1, 0.88
        bottom_h = bottom+height
        left_h = left+width
        rect_scatter = [left, bottom, width, height]
        rect_notes = [left_h, bottom, 0.13, height]
        
        
        fig = plt.figure(figsize=(12,10))
        ax1 = fig.add_axes(rect_scatter)

        
        #ax2 = fig.add_axes([0.05, 0.48, 0.85, 0.4])
    
        
        rh_2d = data['rh_2d']
        rh_2d = np.asarray(rh_2d)
        rh_2d[np.where(rh_2d == 99999.0)] = np.nan
        rh_2d = np.transpose(rh_2d)
        #rh_2d = rh_2d[:,::-1]
        temp_2d = data['temp_2d'] 
        temp_2d = np.asarray(temp_2d)
        temp_2d[np.where(temp_2d == 99999.0)] = np.nan
        temp_2d = temp_2d -273.15
        temp_2d = np.transpose(temp_2d)
        #temp_2d = temp_2d[:,::-1]
        height = np.asarray(data['height'])
        height_new = np.asarray(data['ynew'])
        temp_new = np.asarray(data['ztemp_new']) 
        temp_new = np.asarray(temp_new)
        temp_new[np.where(temp_new == 99999.0)] = np.nan
        temp_new = temp_new -273.15
        temp_new = np.transpose(temp_new)
        print temp_2d.shape
        print temp_new.shape
        rh_new = data['zrh_new']
        rh_new = np.asarray(rh_new)
        rh_new[np.where(rh_new == 99999.0)] = np.nan
        rh_new = np.transpose(rh_new)
        size = temp_new.shape

        s_dates = data['s_dates']
        #s_dates = s_dates[::-1]
        xx = np.arange(len(s_dates))
        yy = range(len(height_new))
        smooth_kernel_x = 0.8
        smooth_kernel_y = 2
        rh_new = ndimage.gaussian_filter(rh_new,[smooth_kernel_x,smooth_kernel_y])
        #temp_2d = ndimage.gaussian_filter(temp_2d,[smooth_kernel_x,smooth_kernel_y])
        temp_new = ndimage.gaussian_filter(temp_new,[smooth_kernel_x,smooth_kernel_y])
        levels = range(0,110,10)
        colors  = ['#b0b0ff', '#cacaff', '#e3e3ff', '#e5fee5', '#cbffcb', '#b2ffb2', '#99ff99', '#65ff65', '#34ff34', '#00ff00']
        
        #levels = np.arange(5,105,5)
        cs = ax1.contourf(xx,yy,rh_new[:,::-1],levels = levels)
        levels_temp = range(-40,40,4)
        cs2 = ax1.contour(xx,yy,temp_new[:,::-1],levels=levels_temp,colors='k',linewidth=4)
        ax1.xaxis.set_major_formatter(nullfmt)
        clabels = plt.clabel(cs2, cs2.levels, fmt='%d',fontsize=18)
                
        #[txt.set_backgroundcolor('gray') for txt in clabels]
        #plt.gca().invert_xaxis()
        
        '''
        ss = str(s_dates[0])[0:14]+'00' +' - ' + str(s_dates[-1])[0:14]+'00'
        title(ss,fontproperties =  zhfont_bold,fontsize=18)
        '''        
        
        ax1.axis([0,size[1],0,size[0]+1])
        
        '''
        i = 0
        hour_index = []
        hour_text = []
        for i in range(len(s_dates)):
            s = s_dates[i].timetuple()
            year,month,day,hour,mm = s[0],s[1],s[2],s[3],s[4]
            #print year,month,day,hour,mm
            if mm == 1:
                hour_index.append( s_dates[i])
                hour_text.append(str(hour).zfill(2))
               
        plt.xticks(hour_index,hour_text[::-1],fontproperties = zhfont,fontsize=14)
        plt.xlabel(u'时间',fontproperties = zhfont,fontsize=14)
        
        
        height_index = []
        height_text = ['1.0','2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0','10.0']
        for i in range(len(height_new)):
            if str(np.round(height_new[i],1)) in height_text:
                  height_index.append(height_new[i])
        '''
        myticks = range(20)
        myticks2 = [v*3 for v in myticks]
        mylabels =[]
        
        mylabels = [str(int(v*1000+488)) for v in (height_new[myticks2]).tolist()]
        plt.yticks(myticks2,mylabels,rotation=0,size=8,weight='bold',fontproperties = zhfont,fontsize=14)
                
        ax1.text(-size[1]/40,size[0]+1,'m',size=10,weight='bold')
                      
        
        #plt.yticks(height_index,height_text,fontproperties =  zhfont,fontsize=14)
        
        #plt.ylabel(u'高度(KM)',fontproperties = zhfont,fontsize=14)
        
        cax = plt.axes(rect_notes)
        
        cax2 = plt.axes([0.88,0.3,0.03,0.4])
        
        cax.xaxis.set_major_formatter(nullfmt)
        cax.yaxis.set_major_formatter(nullfmt)
        plt.colorbar(cs,format='%.2f',cax=cax2)        
        
        cax.text(1,25,u'相对湿度(%)',verticalalignment='center',rotation=90,fontproperties =  zhfont)        
        
        cax.axis([0,14,0,50])
        #cb1.set_label(u'相对湿度(%)',fontproperties =  zhfont,fontsize=14)
        
        
        plt.savefig(outdir + os.sep + outname + '_24h_new_rh_4.png',transparent=True,dpi=100)
        #plt.show()
        plt.close()
        
        
        '''
        #-------------5km------------------------------------
        fig = figure(figsize=(10,6))
        ax1 = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        #ax2 = fig.add_axes([0.05, 0.48, 0.85, 0.4])
        
        
        rh_2d = data['rh_2d']
        rh_2d = np.asarray(rh_2d)
        rh_2d[np.where(rh_2d == 99999.0)] = np.nan
        rh_2d = np.transpose(rh_2d)
        rh_2d = rh_2d[:26,:]
        temp_2d = data['temp_2d'] 
        temp_2d = np.asarray(temp_2d)
        temp_2d[np.where(temp_2d == 99999.0)] = np.nan
        temp_2d = temp_2d -273.15
        temp_2d = np.transpose(temp_2d)
        temp_2d = temp_2d[:26,:]
        height = np.asarray(data['height'])
        height = height[:26]
        s_dates = data['s_dates']
        #s_dates = s_dates[::-1]
        xx = np.arange(len(s_dates))
        
        smooth_kernel_x = 0.8
        smooth_kernel_y = 2
        rh_2d = ndimage.gaussian_filter(rh_2d,[smooth_kernel_x,smooth_kernel_y])
        temp_2d = ndimage.gaussian_filter(temp_2d,[smooth_kernel_x,smooth_kernel_y])
        levels = range(0,110,10)
        colors  = ['#b0b0ff', '#cacaff', '#e3e3ff', '#e5fee5', '#cbffcb', '#b2ffb2', '#99ff99', '#65ff65', '#34ff34', '#00ff00']
        
        #levels = np.arange(5,105,5)
        cs = ax1.contourf(s_dates,height,rh_2d[:,:],levels = levels,extend='max')
        levels_temp = [40,35,30,25,20,15,10,5,0,-5,-10,-15,-20,-25,-30]
        cs2 = ax1.contour(s_dates,height,temp_2d[:,:],levels=levels_temp,colors='k',linewidth=4)
        
        clabels = plt.clabel(cs2, cs2.levels, fmt='%d',fontsize=18)
                
        #[txt.set_backgroundcolor('gray') for txt in clabels]
        #plt.gca().invert_xaxis()
        
        ss = str(s_dates[0])[0:14]+'00' +' - ' + str(s_dates[-1])[0:14]+'00'
        title(ss,fontproperties =  zhfont_bold,fontsize=18)
        
        
        i = 0
        hour_index = []
        hour_text = []
        for i in range(len(s_dates)):
            s = s_dates[i].timetuple()
            year,month,day,hour,mm = s[0],s[1],s[2],s[3],s[4]
            #print year,month,day,hour,mm
            if mm == 1:
                hour_index.append( s_dates[i])
                hour_text.append(str(hour).zfill(2))
        
             
             
                        
        
        plt.xticks(hour_index,hour_text,fontproperties =  zhfont,fontsize=14)
        plt.xlabel(u'时间',fontproperties =  zhfont,fontsize=14)
        
        height_index = []
        height_text = ['1.0','2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0','10.0']
        for i in range(len(height)):
            if str(np.round(height[i],1)) in height_text:
                  height_index.append(height[i])
        
                
        
        
        plt.yticks(height_index,height_text,fontproperties =  zhfont,fontsize=14)
        
        plt.ylabel(u'高度(KM)',fontproperties =  zhfont,fontsize=14)
        
        cax = fig.add_axes(colorbarscale)
        cb1 = colorbar(cs,cax=cax)
        cb1.set_label(u'相对湿度(%)',fontproperties =  zhfont,fontsize=14)
        
        
        plt.savefig(outdir + os.sep + outname + '_24h_blow_5.png')
        plt.close()
        '''

        
    def draw_pic6h(self,data,mainscale = [0.1, 0.1, 0.8, 0.8],colorbarscale=[0.91, 0.1, 0.02, 0.8],outdir = '',outname = ''):
        '''
        绘制6小时范围内的数据
        '''
        rcParams['axes.labelsize'] = 18.0
        zhfont_bold = Font_manager.FontProperties(fname='D:\operation\smear-master\smear\simsun-bold.ttf')
        zhfont = Font_manager.FontProperties(fname='D:\operation\smear-master\smear\simsun.ttc')
        #----------------------------------------------------------------------
        fig = figure(figsize=(10,6))
        ax1 = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        #ax2 = fig.add_axes([0.05, 0.48, 0.85, 0.4])
    
        
        rh_2d = data['rh_2d']
        rh_2d = np.asarray(rh_2d)
        rh_2d[np.where(rh_2d == 99999.0)] = np.nan
        rh_2d = np.transpose(rh_2d)
        #rh_2d = rh_2d[:,::-1]
        temp_2d = data['temp_2d'] 
        temp_2d = np.asarray(temp_2d)
        temp_2d[np.where(temp_2d == 99999.0)] = np.nan
        temp_2d = temp_2d -273.15
        temp_2d = np.transpose(temp_2d)
        #temp_2d = temp_2d[:,::-1]
        height = np.asarray(data['height'])
        
        s_dates = data['s_dates']
        #s_dates = s_dates[::-1]
        xx = np.arange(len(s_dates))
        
        smooth_kernel_x = 0.5
        smooth_kernel_y = 0.8
        rh_2d = ndimage.gaussian_filter(rh_2d,[smooth_kernel_x,smooth_kernel_y])
        temp_2d = ndimage.gaussian_filter(temp_2d,[smooth_kernel_x,smooth_kernel_y])
        levels = range(0,110,10)
        colors  = ['#b0b0ff', '#cacaff', '#e3e3ff', '#e5fee5', '#cbffcb', '#b2ffb2', '#99ff99', '#65ff65', '#34ff34', '#00ff00']
        
        #levels = np.arange(5,105,5)
        cs = ax1.contourf(s_dates,height,rh_2d[:,:],levels = levels,extend='max')
        levels_temp = [40,30,20,10,0,-10,-20,-30,-40]
        cs2 = ax1.contour(s_dates,height,temp_2d[:,:],levels=levels_temp,colors='k',linewidth=4)
        
        clabels = plt.clabel(cs2, cs2.levels, fmt='%d',fontsize=18)
                
        #[txt.set_backgroundcolor('gray') for txt in clabels]
        #plt.gca().invert_xaxis()
        
        ss = str(s_dates[0])[0:14]+'00' +' - ' + str(s_dates[-1])[0:14]+'00'
        title(ss,fontproperties =  zhfont_bold,fontsize=18)
        
        
        i = 0
        hour_index = []
        hour_text = []
        for i in range(len(s_dates)):
            s = s_dates[i].timetuple()
            year,month,day,hour,mm = s[0],s[1],s[2],s[3],s[4]
            #print year,month,day,hour,mm
            if mm == 1:
                hour_index.append( s_dates[i])
                hour_text.append(str(hour).zfill(2))
          
              
        plt.xticks(hour_index,hour_text,fontproperties =  zhfont,fontsize=14)
        plt.xlabel(u'时间',fontproperties =  zhfont,fontsize=14)
        
        height_index = []
        height_text = ['1.0','2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0','10.0']
        for i in range(len(height)):
            if str(np.round(height[i],1)) in height_text:
                  height_index.append(height[i])
               
    
        plt.yticks(height_index,height_text,fontproperties =  zhfont,fontsize=14)
        
        plt.ylabel(u'高度(KM)',fontproperties =  zhfont,fontsize=14)
        
        cax = fig.add_axes(colorbarscale)
        cb1 = colorbar(cs,cax=cax)
        cb1.set_label(u'相对湿度(%)',fontproperties =  zhfont,fontsize=14)
        
        
        plt.savefig(outdir + os.sep + outname + '_06h.png')
        plt.close()
        
        
    
        #-------------5km------------------------------------
        fig = figure(figsize=(10,6))
        ax1 = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        #ax2 = fig.add_axes([0.05, 0.48, 0.85, 0.4])
        
        
        rh_2d = data['rh_2d']
        rh_2d = np.asarray(rh_2d)
        rh_2d[np.where(rh_2d == 99999.0)] = np.nan
        rh_2d = np.transpose(rh_2d)
        rh_2d = rh_2d[:26,:]
        temp_2d = data['temp_2d'] 
        temp_2d = np.asarray(temp_2d)
        temp_2d[np.where(temp_2d == 99999.0)] = np.nan
        temp_2d = temp_2d -273.15
        temp_2d = np.transpose(temp_2d)
        temp_2d = temp_2d[:26,:]
        height = np.asarray(data['height'])
        height = height[:26]
        s_dates = data['s_dates']
        #s_dates = s_dates[::-1]
        xx = np.arange(len(s_dates))
        
        smooth_kernel_x = 0.5
        smooth_kernel_y = 0.8
        rh_2d = ndimage.gaussian_filter(rh_2d,[smooth_kernel_x,smooth_kernel_y])
        temp_2d = ndimage.gaussian_filter(temp_2d,[smooth_kernel_x,smooth_kernel_y])
        levels = range(0,110,10)
        colors  = ['#b0b0ff', '#cacaff', '#e3e3ff', '#e5fee5', '#cbffcb', '#b2ffb2', '#99ff99', '#65ff65', '#34ff34', '#00ff00']
        
        #levels = np.arange(5,105,5)
        cs = ax1.contourf(s_dates,height,rh_2d[:,:],levels = levels,extend='max')
        levels_temp = [40,35,30,25,20,15,10,5,0,-5,-10,-15,-20,-25,-30]
        cs2 = ax1.contour(s_dates,height,temp_2d[:,:],levels=levels_temp,colors='k',linewidth=4)
        
        clabels = plt.clabel(cs2, cs2.levels, fmt='%d',fontsize=18)
                
        #[txt.set_backgroundcolor('gray') for txt in clabels]
        #plt.gca().invert_xaxis()
        
        ss = str(s_dates[0])[0:14]+'00' +' - ' + str(s_dates[-1])[0:14]+'00'
        title(ss,fontproperties =  zhfont_bold,fontsize=18)
        
        
        i = 0
        hour_index = []
        hour_text = []
        for i in range(len(s_dates)):
            s = s_dates[i].timetuple()
            year,month,day,hour,mm = s[0],s[1],s[2],s[3],s[4]
            #print year,month,day,hour,mm
            if mm == 1:
                hour_index.append( s_dates[i])
                hour_text.append(str(hour).zfill(2)) 
        
               
                  
        plt.xticks(hour_index,hour_text,fontproperties =  zhfont,fontsize=14)
        plt.xlabel(u'时间',fontproperties =  zhfont,fontsize=14)
        
        height_index = []
        height_text = ['1.0','2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0','10.0']
        for i in range(len(height)):
            if str(np.round(height[i],1)) in height_text:
                  height_index.append(height[i])
        
                
        
        
        plt.yticks(height_index,height_text,fontproperties =  zhfont,fontsize=14)
        
        plt.ylabel(u'高度(KM)',fontproperties =  zhfont,fontsize=14)
        
        cax = fig.add_axes(colorbarscale)
        cb1 = colorbar(cs,cax=cax)
        cb1.set_label(u'相对湿度(%)',fontproperties =  zhfont,fontsize=14)
        
        
        plt.savefig(outdir + os.sep + outname + '_06h_blow_5.png')
        plt.close()
    def height2pressure(self,height):
        '''
        this is from idl procedure
        ;input height
        ;return pressure
        Ro=6371.3*1000.0
        local_latitude=40*!DTOR
        a=9.80616*(1-0.00259*cos(2*local_latitude))/9.80665
        b=Ro*(1+height/Ro)^2*(height)/(Ro+height)
        Z=a*b
        ;
        c=(44331.0-Z)/44331.0
        ;pressure=1013.255*c^(1.0/0.1903)
        ;print,pressure
        pressure = 1013.255 * 10.0^(alog10(c)*(1.0/0.1903))
        return,pressure
        '''
        height = np.array(height)
        Ro=6371.3*1000.0
        local_latitude=np.deg2rad(40.)
        a=9.80616*(1-0.00259*np.cos(2*local_latitude))/9.80665
        b=Ro*(1+height/Ro)**2*(height)/(Ro+height)
        Z=a*b
        c=(44331.0-Z)/44331.0
        pressure = 1013.255 * 10.0**(np.log10(c)*(1.0/0.1903))
        return pressure
    
    def rh2tdew(self,t,rh):
        '''
        ; NAME:
        ;	rh2tdew
        ;
        ; PURPOSE:
        ;	Calculates dew-point temperature for given temperature and
        ;       relative humidity (nearly) according to WMO standard procedure.
        ;       The parameters are slightly adapted however to fit the
        ;       formula of Bolton (1980), see esat.pro for details, which
        ;       is a very close fit to Goff and Gratch.
        ;
        ; CATEGORY:
        ;	atmospheric physics
        ;
        ; CALLING SEQUENCE:
        ;	result=rh2tdew(T,RH)
        ;
        ; EXAMPLE:
        ;       T = 25.                ; T in deg C or K
        ;       RH = (indgen(5)+1)*20
        ;       print,rh2tdew(T,RH)    ; dew point in same units as input T
        ;          prints    0.494527      10.4776      16.7054      21.3125      25.0000
        ;
        ;       Reference: http://www.ofcm.gov/fmh3/text/appendd.htm
        ;
        ; INPUTS:
        ;	T : Scalar or array of temperatures in C or K
        ;	RH: Scalar or array of relative humidities in %
        ;
        ; OPTIONAL INPUT PARAMETERS:
        ;
        ; KEYWORD INPUT PARAMETERS:
        ;
        ; OUTPUTS:
        ;       Calculated dew-point temperature in deg C or in K, depending
        ;       of units of input parameter T.
        '
        '''
                  
        # first, define some constants.
        #b=17.502 
        #c=240.97 
        b=17.67  
        c=243.5   
        
        t= np.array(t)
        rh = np.array(rh)
        #degC or Kelvin?
        if t[0]>105.0 :
            t0 = -273.15 
        else:
            t0 = 0.0
        #print 'rh.shape',rh.shape
        #print 't.shape',t.shape
        #now calculate the dew-point temperature
        fact=np.log(rh/100.)+b*(t+t0)/(c+t+t0)
          
        td=c*fact/(b-fact)- t0
        td[np.where(t == 99999.0)] = np.nan
        #print np.nanmax(td)
        return td
    
    def skewt_hour(self,data,sqltime = '2013-08-12 14:00:00'):
        '''
        绘制6小时或24小时内某一个整点的探空图
        input ：data,可以使最近24小时微波辐射计数据或者最近6小时微波辐射计数据
        '''
        
        #---------对data数据进行时间维数的循环---------------------------------
        #获取指定时间上，垂直方向的温度、气压、相对湿度和露点等廓线信息
        #利用该信息绘制对应时刻的skewt图片
        s_dates = data['s_dates']
        print len(s_dates)
        ii = 0
        index = 0
        for d in s_dates:
            dt  = d.timetuple()
            year,month,day,hour,mm = dt[0],dt[1],dt[2],dt[3],dt[4]
            ss = str(year) + '-' + str(month).zfill(2) + '-' + str(day).zfill(2) + ' '+ str(hour).zfill(2) +':'+str(mm).zfill(2)+':00'
            if ss == sqltime:
                index = ii
            ii += 1
                
            
        #----------------------------------------------------------------------
        rh_2d = data['rh_2d']
        rh_2d = np.asarray(rh_2d)
        rh_2d[np.where(rh_2d == 99999.0)] = np.nan
                
        temp_2d = data['temp_2d'] 
        temp_2d = np.asarray(temp_2d)
        temp_2d[np.where(temp_2d == 99999.0)] = np.nan
        temp_2d = temp_2d -273.15
                
        height = np.asarray(data['height'])
        
        
        
        #pdb.set_trace()
        rh_profiler = rh_2d[index,:]
        temp_profiler = temp_2d[index,:]
        pressure = self.height2pressure(height*1.e3) # km --> m
        tdew = self.rh2tdew(temp_profiler,rh_profiler)
        self.write_2_fortran(temp_profiler,tdew,pressure)
        
        #-----------把探空数据保存成文本，利用fortran程序读取该文本后，计算各种对流指数
        
        
        #---------把廓线内容写成固定的文本格式，调用skewt程序读取文件绘制探空图
        '''
        94975 YMHB Hobart Airport Observations at 00Z 02 Jul 2013
        
        -----------------------------------------------------------------------------
           PRES   HGHT   TEMP   DWPT   RELH   MIXR   DRCT   SKNT   THTA   THTE   THTV
        -----------------------------------------------------------------------------
        1000   59.1   23.34   20.0   81.59   0.0   0.0   0.0   0.0   0.0   0.0
        925   737.7   20.0   18.8   92.55   0.0   0.0   0.0   0.0   0.0   0.0
        850   1465.9   16.51   16.1   97.4   0.0   0.0   0.0   0.0   0.0   0.0
        700   3106.0   10.7   9.9   95.06   0.0   0.0   0.0   0.0   0.0   0.0
        600   4378.2   3.9   -0.2   74.56   0.0   0.0   0.0   0.0   0.0   0.0
        500   5839.0   -4.38   -6.7   83.5   0.0   0.0   0.0   0.0   0.0   0.0
        400   7569.1   -13.4   -14.5   91.34   0.0   0.0   0.0   0.0   0.0   0.0
        300   9703.8   -26.89   -28.4   87.09   0.0   0.0   0.0   0.0   0.0   0.0
        200   12483.7   -50.26   -51.8   83.16   0.0   0.0   0.0   0.0   0.0   0.0
        100   16798.6   -67.23   -77.9   19.97   0.0   0.0   0.0   0.0   0.0   0.0
        '''
        
        ff = open('test_sounding','w')
        ff.write('94975 YMHB Hobart Airport Observations at 00Z 02 Jul 2013\n')
        ff.write('\n')
        ff.write('-----------------------------------------------------------------------------\n')
        ff.write('   PRES   HGHT   TEMP   DWPT   RELH   MIXR   DRCT   SKNT   THTA   THTE   THTV\n')
        ff.write('-----------------------------------------------------------------------------\n')
        #-----下面开始写入各个气压层上的数据----
        for i in range(len(pressure)):
            ff.write('  '.join([str(pressure[i]),str(height[i]*1000),str(temp_profiler[i]),str(tdew[i]),str(rh_profiler[i]),'0','0','0','0','0','0'])+'\n')
        ff.close()
        
        
        #-------------
        sounding=SkewT.Sounding("test_sounding")
        sounding.make_skewt_axes(pmax=1020.,pmin=200.,title = '2013-07-14 08:00(BJT)',info={'model_name':'T639','init_time':'init:'+'2013-07-14 08:00','fb':'valid:'+'000h','lonlat':'115.3E,41.2N'})
        sounding.add_profile(lw=2)
        sounding.lift_parcel(1009.5031123,34.45 , 22.2725355019)
        sounding.fig.savefig("test_sounding.png")
        
        
    
    def write_2_fortran(self,temp_profiler,tdew_profiler,pressure):
        '''
        把数据保存成文本文件，以便用fortran读取，并计算对流参数
        保存的数据为温度、露点和气压
        '''
       
        
        
        np.savetxt("temp_2d.txt", temp_profiler)
        np.savetxt("tdew_2d.txt", tdew_profiler)
        np.savetxt("pressure.txt", pressure)
        
        #os.system(current_path+'\\radiometric_shunyi\\fortran_index\\Debug\\Cpcpmicc.exe')
            
    
if __name__ == '__main__':
    
    radiometric = radiometric()
    
    radiometric.read_config()
    current_path =  os.getcwd()
    ff = open(current_path+'\\radiometric_54406_timeinfo.txt','r')
    lines = ff.readlines()
    ff.close()
    starttime = line[0][:-1]
    endtime =line[1][:-1]
    data = radiometric.merge_data(from_time=starttime,to_time=endtime)
    radiometric.draw_pic(data,outdir = 'd:',outname='radiometric')
    
    #data6h = radiometric.merge_data(from_time='201308120900',to_time='201308121500')
    #radiometric.draw_pic6h(data6h,outdir = 'd:',outname='radiometric')
    #radiometric.skewt_hour(data6h)
