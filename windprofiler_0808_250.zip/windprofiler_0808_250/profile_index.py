#! /usr/bin/env python
#coding=utf-8
import string,os
import numpy as np
from mpl_toolkits.axes_grid.parasite_axes import SubplotHost
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
import glob
from matplotlib import *
from pylab import *

'''
计算风廓线的相关指数
'''
current_path =  string.replace(os.path.dirname(__file__),'\\','/')

def load_data():
    
    wff = np.load(current_path+'\\wff.npy')
    wdd = np.load(current_path+'\\wdd.npy')
    ww = np.load(current_path+'\\ww.npy')
    cn2 = np.load(current_path+'\\cn2.npy')
    height = np.load(current_path+'\\height.npy')
    return wff,wdd,ww,cn2,height
def wind_shear(wff,wdd,height):
    import numpy as np
    '''
    计算低空风切变指数low_shear
    定义低空切变指数I = Vs/(H1-H2),其中Vs为2000 英尺（约609 米）高度下(此处定义约1km以下)
    计算得到的最大风切变，H1,H2分别为与最大风切变对应的两个风矢量所在高度，
    规定H1>H2
    '''
    ss = np.shape(wff)
    print 'shape of ff is ',ss
    low_shear  = []
    try:
        #wff[np.where(wff < 1.0)] = 1.0
        hh  = height[0]
        uu = -wff*np.sin(np.deg2rad(wdd))
        vv = -wff*np.cos(np.deg2rad(wdd))
        index = np.where(hh<1000.)
        #print index[0],index[0][-1]
        new_uu = uu[:,0:index[0][-1]+1]
        new_vv = vv[:,0:index[0][-1]+1]
        size = new_uu.shape
        print 'SIZE OF new uu is ',size
        
        for i in range(size[0]):
            #print 'loop ',i
            u = new_uu[i,:]
            v = new_vv[i,:]
            shear = []
            (i0,j0) = (-999,-999)
            q0 = 0.0
            #print 'len of u is =',len(u)
            for j in range(len(u)-1):                
                for k in range(j+1,len(u)):
                    #print 'j=',j,'k=',k
                    q1 = (u[j]-u[k])**2 + (v[j]-v[k])**2  
                    if np.isnan(q1):
                        pass
                    else:
                        if q1 >= q0:
                            #print u[j],u[k]
                            (i0,j0) = j,k
                            #print 'q1=',q1,(i0,j0),q0,(i0,j0)
                            
                            q0 = q1 
                        

            #print '(i0,j0) = ',(i0,j0) 
            if i0 >=0 and j0 >=0:
                #print 'u(i0),v(i0)=',u[i0],v[i0],u[j0],v[j0],i0,j0,np.abs(hh[i0]-hh[j0])
                #print np.sqrt(q1) / np.abs(hh[i0]-hh[j0])
                sq = (u[i0]-u[j0])**2 + (v[i0]-v[j0])**2
                low_shear.append(np.sqrt(sq) / np.abs(hh[i0]-hh[j0])*1000.)
            else:
                low_shear.append(99999.0)
    except:
        for i in range(ss[1]):
            low_shear.append(99999.0)

    low_shear = np.array(low_shear)
    low_shear[np.where(low_shear == 99999.0)] = np.nan
    #print  'low_shear=',low_shear
    return low_shear

def jet_index(wff,wdd,height):
    import numpy as np
    '''
    可以认为，10km 以上风速大于30m/s为存在高空急流，
    1.5km以下风速在12m/s以上为存在低空急流。
    定义低空急流指数I=12/D(这里该一下，用1.5km以下大于12m/s的最大风速/D)，高空急流指数T=20／H，其中，D为某时刻12m/s 的风速的
    最低位置；H 为某时刻20m/s的风速的最低位置；利用低空急流指数和高空急流指数
    可以定量地表示高、低空20m/s 和12m/s的急流向下扩展的程度，，因此指数I和T越大
    说明20m/s 和12m/s的急流所在的高度越低，对降水也就越有利
    '''
    hh  = height[0]
    ss = np.shape(wff)
    print 'ss = ',ss
    II_12 = []
    II_20 = []
    #-------先计算低空急流指数
    try:
        index = np.where(hh<1500.)
        new_ff = wff[:,0:index[0][-1]+1]
        size = new_ff.shape
        print 'new size of ff',size
       
        
        for i in range(size[0]):#水平方向，时间轴方向
            
            
            ff = new_ff[i,:]  
            #print 'loop ',i,ff
            #print 'the len of ff is ',ff.shape      
            index12 = np.where(ff >=12)   #检查某个时刻0-1500m高度16层中有没有低空急流
            
            
            #print 'index12 = ',index12,len(index12[0])
            if len(index12[0]) > 0:#存在12m/s的风速
                fmax = np.nanmax(ff) #1500m以下的最大风速 (>= 12m/s)
                low_index12 = index12[0][0] #到达12m/s低空急流标准的最低索引
                #print 'the lowest index is ',low_index12
                #print ff[low_index12],wff[low_index12,i],hh[low_index12]
                I12 = fmax / hh[low_index12]*1000.0
                #print 'I12=',I12
                II_12.append(I12)
            else:
                II_12.append(99999.0)
    except:
        for i in range(ss[1]):
            II_12.append(99999.0)
        
    

    #再计算高空急流
    try:
        index = np.where(hh>10000.)
        #print 'index > 10000.',len(index[0])
        if len(index[0]) >0:
            new_ff = wff[:,0:index[0][-1]+1]
            size = new_ff.shape
            for i in range(size[0]):
                #print 'loop ',i
                ff = new_ff[i,:]            
                index20 = np.where(ff >=20)
                #print 'index12 = ',index12,len(index12[0])
                if len(index20[0]) > 0:#存在12m/s的风速
                    fmax = np.nanmax(ff)
                    high_index20 = index20[0][0]
                    #print ff[low_index12],wff[low_index12,i],hh[low_index12]
                    I20 = fmax / hh[high_index20]*1000.0
                    #print 'I20=',I20
                    II_20.append(I20)
                else:
                    II_20.append(99999.0)
    except:
        for i in range(ss[1]):
            II_20.append(99999.0)
        
        

        
    #print 'INDEX OF LOW LEVEL JET I12',II_12
    #print 'INDEX OF LOW LEVEL JET I20',(II_20)
    II_12 = np.array(II_12)
    II_20 = np.array(II_20)
    II_12[np.where(II_12 == 99999.0)] = np.nan
    II_20[np.where(II_20 == 99999.0)] = np.nan
    return II_12,II_20

def draw_index(value,outpic,anno=['']):
    fig1 = plt.figure(figsize=(12,3))
    nullfmt   = NullFormatter()         # no labels
    # definitions for the axes
    left, width = 0.05, 0.8
    bottom, height = 0.1, 0.85
    bottom_h = bottom+height
    left_h = left+width
    rect_scatter = [left, bottom, width, height]
    rect_notes = [left_h, bottom, 0.13, height]
    
    axScatter = plt.axes(rect_scatter)
    p1 = plt.plot(value,'-o', ms=8, lw=2, alpha=0.9, mfc='red',label='dsfsdfd')
    ylim([np.nanmin(value),np.nanmax(value)*1.1])
    xlim([0,len(value)-1])
    axScatter.xaxis.set_major_formatter(nullfmt)
    axnotes = plt.axes(rect_notes)
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)
    axis('off')

    axnotes.axis([0,10,0,10])
    for i in range(len(anno)):
        sss = anno[i]
        axnotes.text(5,10-2-i,anno[i],horizontalalignment='center',fontsize=10)  
    
    
    #legend()
    plt.savefig(outpic,transparent=True,dpi=100)
    #plt.show()
    




if __name__ == '__main__':
    
    (wff,wdd,ww,cn2,height) = load_data()
    #print 'after load the npy file '
    #print 'the shape of data is '
    #print 'shape of wff,wdd',wff.shape,wdd.shape
    #print height[0]
    wshear = wind_shear(wff,wdd,height)
    print  'low_shear=',wshear
    #print wshear
    #(II_12,II_20) = jet_index(wff,wdd,height)
    #print 'low level jet index = ',II_12
    draw_index(wshear,outpic='',anno=['wind shear','m/s.km'])

    