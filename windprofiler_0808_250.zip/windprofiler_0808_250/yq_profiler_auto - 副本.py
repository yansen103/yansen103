#! /usr/bin/env python
#coding=utf-8
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from windprofiler import windprofiler
import glob
from matplotlib import mpl
from pylab import *
import datetime,os,sys
from match_time_aws_profiler import *
#from radar_mosaic import *
#from interp_2d import wgr_congrid
from profile_index  import wind_shear,jet_index,draw_index
import ConfigParser,os,sys,string
config=ConfigParser.ConfigParser()

'''
自动生成最新的风阔线图形
'''
#----------------------------------------------------------------------
current_path =  os.getcwd()
config.readfp(open(current_path+'/his_ini.cfg','r+'))  
indir = config.get('yq','indir')
print '数据文件目录:',indir
files = os.listdir(indir)
files.sort()
files.reverse()
#print files[0]
#获取最新文件的时间

tt = files[0].split('_')[4]
year = tt[0:4]
month = tt[4:6]
day = tt[6:8]
hour = tt[8:10]
minute = tt[10:12]
inteval = 6
#print year,month,day,hour,minute
#转化为北京时间
st = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
sst = st + datetime.timedelta(hours=8)
ss = sst.timetuple()
year = ss[0]
month = ss[1]
day = ss[2]
hour = ss[3]
minute = ss[4]
#写入配置文件
config.readfp(open(current_path+'/his_ini.cfg','r')) 
f= open(current_path+'/his_ini.cfg',"r+")
if 1:
    config.set('yq','year',year)
    config.set('yq','month',month)
    config.set('yq','day',day)
    config.set('yq','hour',hour)
    config.set('yq','minute',minute)
    config.set('yq','inteval',inteval)    

config.write(f)
f.close()



cmd = os.system(current_path+'\\yq_profiler_history.py')

#----------------------------------------------------------------------
current_path =  os.getcwd()
config.readfp(open(current_path+'/his_ini.cfg','r+'))  
indir = config.get('yq','indir')
print '数据文件目录:',indir
files = os.listdir(indir)
files.sort()
files.reverse()
#print files[0]
#获取最新文件的时间
tt = files[0].split('_')[4]
year = tt[0:4]
month = tt[4:6]
day = tt[6:8]
hour = tt[8:10]
minute = tt[10:12]
inteval = 12
#print year,month,day,hour,minute
#转化为北京时间
st = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
sst = st + datetime.timedelta(hours=8)
ss = sst.timetuple()
year = ss[0]
month = ss[1]
day = ss[2]
hour = ss[3]
minute = ss[4]
#写入配置文件
config.readfp(open(current_path+'/his_ini.cfg','r')) 
f= open(current_path+'/his_ini.cfg',"r+")
if 1:
    config.set('yq','year',year)
    config.set('yq','month',month)
    config.set('yq','day',day)
    config.set('yq','hour',hour)
    config.set('yq','minute',minute)
    config.set('yq','inteval',inteval)    

config.write(f)
f.close()



cmd = os.system(current_path+'\\yq_profiler_history.py')

#----------------------------------------------------------------------
current_path =  os.getcwd()
config.readfp(open(current_path+'/his_ini.cfg','r+'))  
indir = config.get('yq','indir')
print '数据文件目录:',indir
files = os.listdir(indir)
files.sort()
files.reverse()
#print files[0]
#获取最新文件的时间
tt = files[0].split('_')[4]
year = tt[0:4]
month = tt[4:6]
day = tt[6:8]
hour = tt[8:10]
minute = tt[10:12]
inteval = 30
#print year,month,day,hour,minute
#转化为北京时间
st = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
sst = st + datetime.timedelta(hours=8)
ss = sst.timetuple()
year = ss[0]
month = ss[1]
day = ss[2]
hour = ss[3]
minute = ss[4]
#写入配置文件
config.readfp(open(current_path+'/his_ini.cfg','r')) 
f= open(current_path+'/his_ini.cfg',"r+")
if 1:
    config.set('hd','year',year)
    config.set('hd','month',month)
    config.set('hd','day',day)
    config.set('hd','hour',hour)
    config.set('hd','minute',minute)
    config.set('hd','inteval',inteval)    

config.write(f)
f.close()



cmd = os.system(current_path+'\\yq_profiler_history.py')
