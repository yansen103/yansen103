#! /usr/bin/env python
#coding=utf-8

import numpy as np
from mpl_toolkits.axes_grid.parasite_axes import SubplotHost
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
import glob
from matplotlib import *
from pylab import *
import datetime
from mpl_toolkits.axes_grid.axislines import SubplotZero
from matplotlib.ticker import ScalarFormatter 
from windprofiler import windprofiler
import ConfigParser,os,sys,string
config=ConfigParser.ConfigParser()






def draw_aws_element2(temp,rh,pres,rain,uu2,vv2,timeinfo,outpic='aws.png'):
    '''
    multi yaxis
    '''
    rc("axes", linewidth=2.0)
    
    fig = plt.figure(figsize=(10,3))
    
    
    host = SubplotHost(fig, 111)
    fig.add_subplot(host)
    plt.subplots_adjust(right=0.85,wspace=0.0,left=0.15,top=0.8)
    nullfmt   = NullFormatter()
    host.set_ylabel("Temperature(degree)")
    host.set_xlabel("time")
    
    par1 = host.twinx()
    par2 = host.twinx()
    par3 = host.twinx() #当前时次累积降水和5分钟降水
    par4 = host.twinx() #风向杆
    #
    par1.set_ylabel("Humidity(%)")
    par2.axis["right"].set_visible(False)
    par3.axis["left"].set_visible(False)
    par3.axis["right"].set_visible(False)
    par4.axis["left"].set_visible(False)
    par4.axis["right"].set_visible(False)
    #
    offset = 60, 0
    new_axisline = par2.get_grid_helper().new_fixed_axis
    par2.axis["right2"] = new_axisline(loc="right",
                                       axes=par2,
                                       offset=offset)
    
    
    par2.axis["right2"].label.set_visible(True)
    par2.axis["right2"].set_label("pressure(hPa)")
    
    #host.xaxis.set_major_formatter(nullfmt)
    par1.xaxis.set_major_formatter(nullfmt)
    par2.xaxis.set_major_formatter(nullfmt)
    
    #par4.xaxis.set_major_formatter(nullfmt)
    myticks = range(0,len(temp)-1,len(temp)/10)
    #myticks = [v*(len(temp)/3) for v in myticks]
    mylabels =[]
    mylabels = [timeinfo[v][8:12] for v in myticks]
    plt.xticks(myticks,mylabels,rotation=60,size=13,weight='bold')
    #print 'aws ticks ================',myticks
    #print 'aws labels ================',mylabels
    
   
    
    

    
    p1, = host.plot(temp, label="Temperature(degree)",color='r',linewidth=2.5)
    p2, = par1.plot(rh, label="humidity(%)",color='g',linewidth=2.5)
    p3, = par2.plot(pres, label="pressure(hPa)",color='b',linewidth=2.5)
    
    rain5 = []
    for i in range(len(rain)-1):
        if rain[i]<rain[i+1]:
            rain5.append(rain[i])
        else:
            rain5.append(rain[i]-rain[i+1])
    rain5.append(0.0)
    rain5 = np.array(rain5)
    if np.nanmax(rain5) != 0.0 : #没有降水
        par3.axis["left2"] = new_axisline(loc="left",
                                    axes=par3,
                                    offset=(-60,0))
    
        par3.axis["left2"].set_label("rain")
        par3.xaxis.set_major_formatter(nullfmt)
        ind = np.arange(len(rain))
        width = 0.5
            #ax.bar(ind,temp,width, color='r')
        p4 = par3.bar(ind,rain,width, color='#CC0000',bottom=0)
        p5 = par3.bar(ind+width,rain5,width, color='#00FF00',bottom=0)
        par3.axis["left2"].label.set_fontsize(14)

    
    
    xx = np.arange(0,len(uu2),1)
    step = len(uu2) / 10
    yy = np.ones(len(uu2))
    par4.barbs(xx[::step], yy[::step], uu2[::step], vv2[::step],length=6,fill_empty=False,barbcolor='#000000',\
             sizes=dict(emptybarb=0.2,spacing=0.20,thick=2.0),barb_increments=dict(half=2, full=4, flag=20))
    
    
    formatter = ScalarFormatter() 
    formatter.set_scientific(False) 
    formatter.set_powerlimits((-3, 5))
    host.set_ylim(np.nanmin(temp)-abs(np.nanmin(temp))*0.05,np.nanmax(temp))
    par1.set_ylim(np.nanmin(rh)-abs(np.nanmin(rh))*0.05, np.nanmax(rh)+np.nanmax(rh)*0.05)
    par2.set_ylim(np.nanmin(pres), np.nanmax(pres))
    par3.set_ylim(-np.nanmax(rain)*0.25, np.nanmax(rain))
    par4.set_ylim(0.2, 5)
    lenx = len(temp)
    host.set_xlim(0,lenx-1)
    par1.set_xlim(0,lenx-1)
    par2.set_xlim(0,lenx-1)
    par3.set_xlim(0,lenx-1)
    par4.set_xlim(0,lenx-1)
    #par2.yaxis.set_major_formatter(formatter) 
    #host.legend()
    
    
    host.axis["left"].label.set_color(p1.get_color())
    par1.axis["right"].label.set_color(p2.get_color())
    par2.axis["right2"].label.set_color(p3.get_color())
    host.axis["left"].label.set_fontsize(14)
    par1.axis["right"].label.set_fontsize(14)
    par2.axis["right2"].label.set_fontsize(14)
    
    
    #----------------pic2-------------------
   
    
    
    plt.savefig(outpic,transparent=True,dpi=100)
    #plt.show()
def draw_aws_element(temp,rh,pres,rain,uu2,vv2,timeinfo,outpic='aws.png'):
    '''
    multi yaxis
    '''
    print 'this is draw_aws_element'
    rc("axes", linewidth=2.0)
    
    fig = plt.figure(figsize=(12,3))
    left, width = 0.1, 0.75
    bottom, height = 0.1, 0.85
    bottom_h = bottom+height
    left_h = left+width
    rect_scatter = [left, bottom, width, height]
    rect_notes = [left_h, bottom, 0.13, height]
    
    #host=plt.axes(rect_scatter,axisbg='r')
    host = SubplotHost(fig, 111)
    fig.add_subplot(host)
    plt.subplots_adjust(right=0.85,wspace=0.0,left=0.1,top=0.8)
    nullfmt   = NullFormatter()
    
    
    par1 = host.twinx()
    par2 = host.twinx()
    par3 = host.twinx() #当前时次累积降水和5分钟降水
    par4 = host.twinx() #风向杆
    
    
    
    
    
    host.xaxis.set_major_formatter(nullfmt)
    host.set_ylabel("Temperature")
    
    #host.yaxis.set_major_formatter(nullfmt)
    par1.xaxis.set_major_formatter(nullfmt)    
    par2.xaxis.set_major_formatter(nullfmt)
    par3.xaxis.set_major_formatter(nullfmt)
    #par1.yaxis.set_major_formatter(nullfmt)
    par1.set_ylabel("humidity(%)")
    par2.axis["right"].set_visible(False)
    
    offset = 60, 0
    new_axisline = par2.get_grid_helper().new_fixed_axis
    par2.axis["right2"] = new_axisline(loc="right",
                                           axes=par2,
                                           offset=offset)
    
    par2.axis["right2"].label.set_visible(True)
    par2.axis["right2"].set_label("pressure(hPa)")
    
    par3.yaxis.set_major_formatter(nullfmt)
    par4.yaxis.set_major_formatter(nullfmt)
    #par4.xaxis.set_major_formatter(nullfmt)
    myticks = range(0,len(temp)-1,len(temp)/10)
    #myticks = [v*(len(temp)/3) for v in myticks]
    mylabels =[]
    mylabels = [timeinfo[v][8:12] for v in myticks]
    plt.xticks(myticks,mylabels,rotation=60,size=13,weight='bold')
    #print 'aws ticks ================',myticks
    #print 'aws labels ================',mylabels
    
   
    
    

    
    p1, = host.plot(temp, label="Temperature(degree)",color='r',linewidth=2.5)
    p2, = par1.plot(rh, label="humidity(%)",color='g',linewidth=2.5)
    p3, = par2.plot(pres, label="pressure(hPa)",color='b',linewidth=2.5)
    
    rain5 = []
    for i in range(len(rain)-1):
        if rain[i]<rain[i+1]:
            rain5.append(rain[i])
        else:
            rain5.append(rain[i]-rain[i+1])
    rain5.append(0.0)
    rain5 = np.array(rain5)
    if np.nanmax(rain5) != 0.0 : #没有降水
       
    
        
        
        ind = np.arange(len(rain))
        width = 0.5
            #ax.bar(ind,temp,width, color='r')
        #p4 = par3.bar(ind,rain,width, color='#CC0000',bottom=0)
        p5 = par3.bar(ind+width,rain5,width, color='#00FF00',bottom=0)
        

    
    
    xx = np.arange(0,len(uu2),1)
    step = len(uu2) / 10
    yy = np.ones(len(uu2))
    par4.barbs(xx[::step], yy[::step], uu2[::step], vv2[::step],length=6,fill_empty=False,barbcolor='#000000',\
             sizes=dict(emptybarb=0.2,spacing=0.20,thick=2.0),barb_increments=dict(half=2, full=4, flag=20))
    
    
    
    host.axis["left"].label.set_color(p1.get_color())
    par1.axis["right"].label.set_color(p2.get_color())
    par2.axis["right2"].label.set_color(p3.get_color())
    
  
    '''
    axnotes = plt.axes(rect_notes)
    axnotes.xaxis.set_major_formatter(nullfmt)
    axnotes.yaxis.set_major_formatter(nullfmt)
    axnotes.axis([0,10,0,10])
    p1, = axnotes.plot([4,4],[2,5], color='r',linewidth=2.5)
    
    
    #axnotes.text(5,10-2-i,anno[i],horizontalalignment='center')  
    '''
    plt.savefig(outpic,transparent=True,dpi=100)
    #plt.show()
    print 'aws done'

    
def draw_station_series(temp,rh,pres,rain,uu2,vv2,timeinfo,outpic='aws.png'):
    rcParams['xtick.labelsize'] = 9.0
    rcParams['ytick.labelsize'] = 9.0
    fig = figure(figsize=(12,3))
    #ax = plt.axes([0.1,0.1,0.8,0.8],axisbg='#ffffff')#这里用黑色背景先
    nullfmt   = NullFormatter()
    
    lenx = len(temp)
    temp_fig = SubplotHost(fig, 111)
    fig.add_subplot(temp_fig)
    plt.subplots_adjust(right=0.85,wspace=0.0,left=0.05,top=0.9,bottom=0.4)   
    rh_fig = temp_fig.twinx()
    press_fig = temp_fig.twinx() #
    wind_fig = temp_fig.twinx() #风向杆
    #
    

    temp_fig.axis["right"].set_visible(False)
    rh_fig.axis["left"].set_visible(False)
    #rh_fig.axis["right"].set_visible(False)
    press_fig.axis["left"].set_visible(False)
    press_fig.axis["right"].set_visible(False)
    wind_fig.axis["left"].set_visible(False)
    wind_fig.axis["right"].set_visible(False)
    #---
    temp_fig.axis["bottom"].set_visible(False)
    rh_fig.axis["bottom"].set_visible(False)
    press_fig.axis["bottom"].set_visible(False)
    
    temp_plot, = temp_fig.plot(temp,'-o', ms=5, lw=2, alpha=0.7, mfc='red')
    temp_fig.axis["left"].set_label("temprature(deg)") 
    temp_fig.axis["left"].label.set_color("red")
    locs ,labels = yticks()
    
    #yticks(locs,v_labels)
    #


    rh_plot, = rh_fig.plot(rh,'-o', ms=5, lw=2, alpha=0.7, mfc='green')
    rh_fig.axis["right"].set_label("humidity(%)")
    rh_fig.axis["right"].label.set_color("green")
    
    
    offset = 40, 0
    new_axisline = temp_fig.get_grid_helper().new_fixed_axis
    press_fig.axis["right2"] = new_axisline(loc="right",
                                           axes=press_fig,
                                           offset=offset)
        
    press_plot, = press_fig.plot(pres,'-o', ms=5, lw=2, alpha=0.7, mfc='blue')
    press_fig.axis["right2"].set_label("pressure(hPa)")
    press_fig.axis["right2"].label.set_color("blue")
    
    
    text(lenx/2, (np.nanmax(temp)+np.nanmin(temp))*0.5, "Beijing Weather", fontsize=24,alpha=0.6,rotation=0,horizontalalignment='center')
    
    
    xlim([0,lenx-1])
    
    
    #画风和5分钟降水
    ax2 = plt.axes([0.05,0.1,0.8,0.3])
    
    y = np.zeros(lenx) +20#[20,25,30,24,30,17,30]
    x = np.arange(len(y))
    #uu2 = [3]*len(y)
    #vv2 = [-7]*len(y)
    ax2.barbs(x[::2], y[::2], uu2[::2], vv2[::2],length=6,fill_empty=False,barbcolor='#000000',\
             sizes=dict(emptybarb=0.2,spacing=0.20,thick=2.0),barb_increments=dict(half=2, full=4, flag=20))
    
    
    #rain5m = np.zeros(48)+5
    ind = np.arange(lenx)-0.5
    width = 0.5
    #ax2.plot(rain5m,'o', ms=10, lw=2, alpha=0.7, mfc='blue')           
    p5 = ax2.bar(ind+width,rain,width, color='#00FF00',bottom=0)
    yticks([0,5,10,20],['0','5','10','20'])
    ylabel('rain(mm)')
    
   
    ylim([-2,30])
    xlim([0,lenx-1])
    
    #temp_fig.xaxis.set_major_formatter(nullfmt)
    #temp_fig.yaxis.set_major_formatter(nullfmt)
    #par1.xaxis.set_major_formatter(nullfmt)
    #temp_fig.xaxis.set_major_formatter(nullfmt)
    #temp_fig.axis["right2"].set_label("time")
    myticks = range(0,lenx-1,lenx/6)
    myticks.append(lenx-1)
    mylabels =[]
    mylabels = [timeinfo[v][8:12] for v in myticks]
    xticks(myticks,mylabels,rotation=20,size=8,weight='bold')
   
    
   
    
    
    plt.savefig(outpic,transparent=True,dpi=100)

    
    
def read_aws(file):
    '''
    读取自动站文件
    '''
    #print file
    try:            
        f = open(file,'r')
        lines  =  f.readlines()
        f.close()
    except:
        pass
    data = []
    for line in lines:
        aws_data = line.split(' ')
        #print len(aws_data)
        try:
            aws_time = aws_data[0]
        except:
            aws_time = ''
        try:
            aws_st_num = aws_data[1]
        except:
            aws_st_num = ''
        try:
            aws_st_sty = aws_data[2]
        except:
            aws_st_sty = ''
        try:
            aws_ave2_wdd = aws_data[3]
        except:
            aws_ave2_wdd = ''
        try:
            aws_ave2_wff = aws_data[4]
        except:
            aws_ave2_wff = ''
        try:
            aws_ave10_wdd = aws_data[5]
        except:
            aws_ave10_wdd = ''
        try:
            aws_ave10_wff = aws_data[6]
        except:
            aws_ave10_wff = ''
        try:
            aws_max_wdd = aws_data[7]
        except:
            aws_max_wdd = ''
        try:
            aws_max_wff = aws_data[8]
        except:
            aws_max_wff = ''
        try:
            aws_max_wind_time = aws_data[9]
        except:
            aws_max_wind_time = ''
        try:
            aws_shunshi_wdd = aws_data[10]
        except:
            aws_shunshi_wdd = ''
        try:
            aws_shunshi_wff = aws_data[11]
        except:
            aws_shunshi_wff = ''
        try:
            aws_jida_wdd = aws_data[12]
        except:
            aws_jida_wdd = ''
        try:
            aws_jida_wff = aws_data[13]
        except:
            aws_jida_wff = ''
        try:
            aws_jida_wind_time = aws_data[14]
        except:
            aws_jida_wind_time = ''
        try:
            aws_rain_1m = aws_data[15]
        except:
            aws_rain_1m = ''
        try:
            aws_rain_1h = aws_data[16]
        except:
            aws_rain_1h = ''
        try:
            aws_temp = aws_data[17]
        except:
            aws_temp = ''
        try:
            aws_max_temp = aws_data[18]
        except:
            aws_max_temp = ''
        try:
            aws_max_temp_time = aws_data[19]
        except:
            aws_max_temp_time = ''
        try:
            aws_min_temp = aws_data[20]
        except:
            aws_min_temp = ''
        try:
            aws_min_temp_time = aws_data[21]
        except:
            aws_min_temp_time = ''
        try:
            aws_rh = aws_data[22]
        except:
            aws_rh = ''
        try:
            aws_min_rh = aws_data[23]
        except:
            aws_min_rh = ''
        try:
            aws_min_rh_time = aws_data[24]
        except:
            aws_min_rh_time = ''
        try:
            aws_pres = aws_data[25]
        except:
            aws_pres = ''
        try:
            aws_max_pres_time = aws_data[26]
        except:
            aws_max_pres_time = ''
        
        try:
            aws_surface_temp = aws_data[31]
        except:
            aws_surface_temp = ''
            
        result = {'aws_time':aws_time,'aws_st_num':aws_st_num,'aws_st_sty':aws_st_sty,\
                 'aws_ave2_wdd':aws_ave2_wdd,'aws_ave2_wff':aws_ave2_wff,'aws_ave10_wdd':aws_ave10_wdd,\
                'aws_ave10_wff':aws_ave10_wff,'aws_max_wdd':aws_max_wdd,'aws_max_wff':aws_max_wff,\
                'aws_max_wind_time':aws_max_wind_time,'aws_shunshi_wdd':aws_shunshi_wdd,\
                'aws_shunshi_wff':aws_shunshi_wff,'aws_jida_wdd':aws_jida_wdd,\
                'aws_jida_wff':aws_jida_wff,'aws_jida_wind_time':aws_jida_wind_time,\
                'aws_rain_1m':aws_rain_1m,'aws_rain_1h':aws_rain_1h,'aws_temp':aws_temp,\
                'aws_max_temp':aws_max_temp,'aws_max_temp_time':aws_max_temp_time,'aws_min_temp':aws_min_temp,\
                'aws_min_temp_time':aws_min_temp_time,'aws_rh':aws_rh,'aws_min_rh_time':aws_min_rh_time,\
                'aws_pres':aws_pres,'aws_max_pres_time':aws_max_pres_time,'aws_surface_temp':aws_surface_temp}
        
        
        data.append(result)
    return data

def match_time_aws(start_time,end_time):
    '''
    根据风廓线文件的时间，找到最接近或对应的自动站文件
    '''
    #start_time = datetime.datetime(2010,4,26,10,36)
    #end_time =  datetime.datetime(2010,4,26,2,12)
    st = start_time.timetuple()
    st_minute = st[4]
    #print 'the start minute is ',st_minute
    num5 = int(st_minute) / 5
    #print 'num of 5 minutes is ',num5 #起始时间至少包含几个5分钟
    #所以对应的最接近的AWS时间（分钟）是num5*5 分钟
    aws_minute = num5 * 5
    #print 'start aws_minute is ',aws_minute
    #从这个时次开始往前循环，间隔5分钟
    s1 = datetime.datetime(int(st[0]),int(st[1]),int(st[2]),int(st[3]),aws_minute)
    aws_time_list = []
    aws_time_list.append(s1)

    while 1:
        s2 = s1 +datetime.timedelta(minutes = -5)
        
        #print 's2 = ',s2
        s1 =  s2
        if s2 < end_time:
            break
        else:            
            aws_time_list.append(s2)
    return aws_time_list


def get_aws_timeserier(files,id='54399'):
    '''
    显示单站点(自动站)的要素时序图
    时间轴从左到右，与风廓线统一
    '''
    
    
    #id = 54399
    temp = []
    rh = []
    pres = []
    rain = [] 
    wff2 = []
    wdd2 = []
    shunshi_wff = []
    shunshi_wdd = []
    timeinfo = []

    for file in files:
        try:
            data = read_aws(file)
            for i in range(len(data)):
                ids = data[i]['aws_st_num']
                #print data[i]
                if ids == id:
                    #print 'get 54399 station'
                    try:
                        timeinfo.append(data[i]['aws_time'])
                    except:
                        timeinfo.append('')
                    try:
                        temp.append(float(data[i]['aws_temp'])*0.1)
                    except:
                        temp.append(99999.0)
                    try:
                        rh.append(float(data[i]['aws_rh']))
                    except:
                        rh.append(99999.0)
                    try:
                        pres.append(float(data[i]['aws_pres'])*0.1)
                    except:
                        pres.append(99999.0)
                    try:
                        rain.append(float(data[i]['aws_rain_1h'])*0.1)
                    except:
                        rain.append(99999.0)
                    try:
                        wff2.append(float(data[i]['aws_ave2_wff'])*0.1)
                    except:
                        wff2.append(99999.0)
                    try:
                        wdd2.append(float(data[i]['aws_ave2_wdd']))
                    except:
                        wdd2.append(99999.0)
                    try:
                        shunshi_wff.append(float(data[i]['aws_shunshi_wff'])*0.1)
                    except:
                        shunshi_wff.append(99999.0)
                    try:
                        shunshi_wdd.append(float(data[i]['aws_shunshi_wdd']))
                    except:
                        shunshi_wdd.append(99999.0)
        except:
            timeinfo.append('            ')
            temp.append(99999.0)
            rh.append(99999.0)
            pres.append(99999.0)
            rain.append(99999.0)
            wff2.append(99999.0)
            wdd2.append(99999.0)
            shunshi_wdd.append(99999.0)
            shunshi_wff.append(99999.0)
            

                
                

    return {'timeinfo':timeinfo,'temp':temp,'rh':rh,'pres':pres,'rain':rain,\
            'wff2':wff2,'wdd2':wdd2,'shunshi_wff':shunshi_wff,'shunshi_wdd':shunshi_wdd}

    
'''
current_path =  string.replace(os.path.dirname(__file__),'\\','/')
config.readfp(open(current_path+'/ini.cfg','r'))  
indir = config.get('aws5','indir')        
outdir = config.get('aws5','outdir')



            
start_time = datetime.datetime(2009,07,31,4,36)
end_time = datetime.datetime(2009,07,31,01,36)
aws_time_list = match_time_aws(start_time,end_time)
aws_file_list = []
for item in aws_time_list:
    ss = item.timetuple()
    st = str(ss[0])+str(ss[1]).zfill(2)+str(ss[2]).zfill(2)+str(ss[3]).zfill(2)+str(ss[4]).zfill(2)+'00'
    #aws_file_list.append(r'x:\aws'+'\\'+'BJAWS_'+st+'.TXT')
    aws_file_list.append(r'C:\mywork\data\aws5\20090730'+'\\'+'BJAWS_'+st+'.TXT')
    #print r'C:\mywork\code\idl\aws\aws_data\20091031-20091101aws'+'\\'+'BJAWS_'+st+'.TXT'

data = get_aws_timeserier(aws_file_list)




timeinfo = data['timeinfo']
temp = data['temp']
rh = data['rh']
pres = data['pres']
rain = data['rain']
wff2 = data['wff2']
wdd2 = data['wdd2']
shunshi_wff = data['shunshi_wff']
shunshi_wdd = data['shunshi_wdd']

temp = np.array(temp)
rh = np.array(rh)
pres = np.array(pres)
rain = np.array(rain)
wff2 = np.array(wff2)
wdd2 = np.array(wdd2)

temp[np.where(temp == 99999.0)] = np.nan
rh[np.where(rh == 99999.0)] = np.nan
pres[np.where(pres == 99999.0)] = np.nan
rain[np.where(rain ==99999.0)] = np.nan
wff2[np.where(wff2 ==99999.0)] = np.nan
wdd2[np.where(wdd2 ==99999.0)] = np.nan
wff2[np.where(wff2 < 1.0)] = 1.0
uu2 = -wff2*np.sin(np.deg2rad(wdd2))
vv2 = -wff2*np.cos(np.deg2rad(wdd2))

print 'temp=',temp
print 'rh=',rh
print 'pres=',pres
print 'rain=',rain
#r = draw_lines(temp,rh,pres,rain)
print 'minpres',np.nanmin(pres)
print 'maxpres',np.nanmax(pres)
print 'timeinfo',timeinfo
r=draw_aws_element(temp,rh,pres,rain,uu2,vv2,timeinfo)
'''