#! /usr/bin/env python
#coding=utf-8
from netCDF4  import Dataset
import numpy as np
import os,datetime

file = r'V:\vips\data\windprofiler\zb\WPRD_W_ROBS_53399_20100823031735.nc'
f= Dataset(file,'r')

wdd = f.variables['wdh'][:]
wff = f.variables['wsh'][:]
ww = f.variables['wsv'][:]
cn2 = f.variables['wdvCN2'][:]
height = f.variables['hh'][:]

#时间信息
sst = os.path.basename(file)[-17:]
year = sst[0:4]
month = sst[4:6]
day=sst[6:8]
hour = sst[8:10]
minute = sst[10:12]
tt1 = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute))
tt2  = tt1 + datetime.timedelta(hours = 8)#世界时转化为北京时
timeinfo = str(tt2)

mask = np.where(np.logical_and(wdd <0,wdd>360)) 
wdd[mask]=  99999.9
mask = np.where(np.logical_and(wff <0,wff>100)) 
wff[mask]=  99999.9
mask = np.where(ww>100) 
ww[mask]=  99999.9
mask = np.where(cn2>1000) 
cn2[mask]=  99999.9

mask = np.where(height>10000) 
height[mask]=  99999.9

data = {'height':height,'wdd':wdd,'wff':wff,'ww':ww,'cn2':cn2,'timeinfo':timeinfo}
#return data

